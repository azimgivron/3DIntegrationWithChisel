// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VTestHarness.h for the primary calling header

#include "VTestHarness.h"
#include "VTestHarness__Syms.h"

#include "verilated_dpi.h"

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2679(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2679\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_11\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_11\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_11\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_11\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_11\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_11__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_11\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2680(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2680\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_12_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_12__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_12_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_12__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_12\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_11\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_11\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_11\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_11\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_11\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_11__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_11\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2681(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2681\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_10\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_10\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_10\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_10\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_10\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_10__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_10\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2682(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2682\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_11_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_11__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_11_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_11__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_11\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_10\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_10\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_10\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_10\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_10\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_10__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_10\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2683(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2683\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_9\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_9\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_9\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_9\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_9\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_9__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_9\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2684(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2684\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_10_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_10__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_10_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_10__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_10\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_9\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_9\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_9\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_9\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_9\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_9__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_9\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2685(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2685\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_8\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_8\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_8\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_8\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_8\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_8__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_8\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2686(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2686\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_9_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_9__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_9_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_9__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_9\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_8\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_8\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_8\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_8\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_8\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_8__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_8\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2687(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2687\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_7__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2688(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2688\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_8_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_8__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_8_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_8__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_8\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_7__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2689(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2689\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_6__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2690(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2690\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_7__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_6__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2691(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2691\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_5__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2692(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2692\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_6_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_6__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_6_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_6__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_5__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2693(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2693\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_4__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2694(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2694\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_5_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_5__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_5_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_5__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_4__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2695(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2695\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_3__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2696(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2696\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_4_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_4__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_4_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_4__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_3__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2697(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2697\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_2__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2698(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2698\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_3_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_3__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_3_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_3__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_2__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2699(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2699\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_2_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_2__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_2_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_2__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2701(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2701\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__ftq__DOT__ftq_bundle_ram_history__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rob__DOT__rob_fflags_1__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rob__DOT__rob_fflags_1__v1 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rob__DOT__rob_fflags_1__v2 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rob__DOT__rob_fflags__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rob__DOT__rob_fflags__v1 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rob__DOT__rob_fflags__v2 = 0U;
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:244948:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__bim__DOT___T_182))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at bim.scala:293 assert(!(uq.io.deq.valid && getBankFromIdx(uq.io.deq.bits.entry_idx) =/= w.U))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:244959:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__bim__DOT___T_182))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:244962: Assertion failed in %NTestHarness.top.boom_tile.frontend.bpdpipeline.btb.bim\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 244962, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:244970:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__bim__DOT___T_355))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at bim.scala:293 assert(!(uq.io.deq.valid && getBankFromIdx(uq.io.deq.bits.entry_idx) =/= w.U))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:244981:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__bim__DOT___T_355))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:244984: Assertion failed in %NTestHarness.top.boom_tile.frontend.bpdpipeline.btb.bim\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 244984, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2702(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2702\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:204868:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core_io_ifu_commit_valid) 
                          | (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rob__DOT___T_2752)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__ftq__DOT___T_22))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: FTQ received conflicting flush and deq on same cycle\n    at fetch-target-queue.scala:176 assert (!(io.deq.valid && io.flush.valid && io.deq.bits =/= io.flush.bits.ftq_idx),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:204879:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core_io_ifu_commit_valid) 
                          | (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rob__DOT___T_2752)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__ftq__DOT___T_22))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:204882: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller.ftq\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 204882, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:204890:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__ftq__DOT___T_103))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [ftq] this code depends on this assumption\n    at fetch-target-queue.scala:322 assert (!(io.flush.valid && RegNext(io.com_ftq_idx) =/= io.flush.bits.ftq_idx),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:204901:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__ftq__DOT___T_103))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:204904: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller.ftq\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 204904, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2709(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2709\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_2_bits_uop_pdst 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_2_bits_uop_pdst;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2712(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2712\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_1_bits_uop_pdst 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_1_bits_uop_pdst;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2728(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2728\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_0_bits_uop_pdst 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_0_bits_uop_pdst;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__mem_xcpt_uops_0_rob_idx 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__mem_xcpt_uops_0_rob_idx;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__mem_xcpt_uops_0_br_mask 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__mem_xcpt_uops_0_br_mask;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2740(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2740\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_3_bits_addr_bits 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_3_bits_addr_bits;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_2_bits_addr_bits 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_2_bits_addr_bits;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_1_bits_addr_bits 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_1_bits_addr_bits;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_0_bits_addr_bits 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_0_bits_addr_bits;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2742(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2742\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_31_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_31_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_30_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_30_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_29_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_29_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_28_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_28_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_27_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_27_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_26_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_26_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_25_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_25_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_24_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_24_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_23_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_23_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_22_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_22_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_31_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_31_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_30_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_30_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_29_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_29_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_28_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_28_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_27_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_27_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_26_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_26_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_25_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_25_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_24_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_24_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_23_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_23_valid;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2743(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2743\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_22_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_22_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_21_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_21_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_20_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_20_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_19_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_19_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_18_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_18_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_17_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_17_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_16_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_16_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_15_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_15_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_14_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_14_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_13_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_13_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_12_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_12_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_11_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_11_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_10_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_10_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_9_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_9_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_8_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_8_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_7_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_7_valid;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2744(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2744\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_6_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_6_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_5_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_5_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_4_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_4_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_3_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_3_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_2_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_2_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_1_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_1_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_0_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__ldq_0_valid;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2745(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2745\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_21_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_21_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_20_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_20_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_19_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_19_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_18_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_18_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_17_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_17_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_16_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_16_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_15_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_15_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_14_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_14_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_13_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_13_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_12_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_12_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_11_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_11_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_10_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_10_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_9_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_9_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_8_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_8_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_7_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_7_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_6_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_6_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_5_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_5_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_4_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_4_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_3_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_3_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_2_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_2_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_1_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_1_valid;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_0_valid 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__stq_0_valid;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2746(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2746\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:247058:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__bpd__DOT___T_31))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [bpd] if a F2 redirect occurs, F2-hist should equal F1-hist.\n    at br-predictor.scala:224 assert (!io.f2_redirect || r_f2_history === r_f1_history,\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:247069:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__bpd__DOT___T_31))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:247072: Assertion failed in %NTestHarness.top.boom_tile.frontend.bpdpipeline.bpd\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 247072, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:247080:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__bpd__DOT___T_37))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at br-predictor.scala:237 assert (q_f3_history.io.enq.ready === !io.f2_stall)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:247091:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__bpd__DOT___T_37))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:247094: Assertion failed in %NTestHarness.top.boom_tile.frontend.bpdpipeline.bpd\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 247094, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:247102:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__bpd__DOT___T_73))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at gshare.scala:206 assert (q_s3_resp.io.enq.ready === !io.f2_stall)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:247113:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__bpd__DOT___T_73))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:247116: Assertion failed in %NTestHarness.top.boom_tile.frontend.bpdpipeline.bpd\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 247116, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:247124:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__bpd__DOT__enable_assert) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__ftq_io_bpd_update_valid)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__bpd__DOT___T_134))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [gshare] disagreement on update indices.\n    at gshare.scala:236 assert (com_idx === com_info.debugIdx, \"[gshare] disagreement on update indices.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:247135:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__bpd__DOT__enable_assert) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__ftq_io_bpd_update_valid)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__bpd__DOT___T_134))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:247138: Assertion failed in %NTestHarness.top.boom_tile.frontend.bpdpipeline.bpd\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 247138, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2748(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2748\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_1__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2749(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2749\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_1__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2750(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2750\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_1_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_1__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_1_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_1__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__3111(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__3111\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_0__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__3112(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__3112\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_0__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__3113(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__3113\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_0__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rob__DOT__rob_exception_1__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rob__DOT__rob_exception_1__v1 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rob__DOT__rob_exception_1__v2 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rob__DOT__rob_exception__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rob__DOT__rob_exception__v1 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rob__DOT__rob_exception__v2 = 0U;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__3114(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__3114\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:242997:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_486) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__q_f3_btb_resp__DOT___T_2_0_bits_bpd_type)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__q_f3_btb_resp__DOT___T_2_0_bits_taken) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at fetch-control-unit.scala:377 assert (f3_btb_resp.bits.taken)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243008:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_486) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__q_f3_btb_resp__DOT___T_2_0_bits_bpd_type)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__q_f3_btb_resp__DOT___T_2_0_bits_taken) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243011: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 243011, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243019:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_486) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__q_f3_btb_resp__DOT___T_2_0_bits_bpd_type))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__q_f3_btb_resp__DOT___T_2_0_bits_taken)) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__q_f3_btb_resp__DOT___T_2_0_bits_bpd_type)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at fetch-control-unit.scala:385 assert (BpredType.isBranch(f3_btb_resp.bits.bpd_type))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243030:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_486) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__q_f3_btb_resp__DOT___T_2_0_bits_bpd_type))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__q_f3_btb_resp__DOT___T_2_0_bits_taken)) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__q_f3_btb_resp__DOT___T_2_0_bits_bpd_type)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243033: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 243033, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243041:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_515))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [bpd_pipeline] mutually-exclusive signals firing\n    at fetch-control-unit.scala:396 assert (PopCount(VecInit(f3_bpd_may_redirect_taken, f3_bpd_may_redirect_next)) <= 1.U,\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243052:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_515))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243055: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 243055, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243063:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_761))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fetch] f4-request is high but f4_valid is not.\n    at fetch-control-unit.scala:520 assert (!(r_f4_req.valid && !r_f4_valid),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243074:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_761))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243077: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 243077, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243085:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_769))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fetch] F4 should be cleared if a F0_redirect due to BRU/Flush/Sfence.\n    at fetch-control-unit.scala:522 assert (!(io.clear_fetchbuffer && !(br_unit.take_pc || io.flush_take_pc || io.sfence_take_pc)),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243096:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_769))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243099: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 243099, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243107:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_902) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_572)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at fetch-control-unit.scala:635 assert (f3_fetch_bundle.mask =/= 0.U)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243118:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_902) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_572)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243121: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 243121, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243129:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___GEN_284) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_cfi_type))) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_954) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fetch] A non-cfi instruction is followed by the wrong instruction.\n    at fetch-control-unit.scala:650 assert (fetch_pc ===  last_nextlinepc,\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243140:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___GEN_284) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_cfi_type))) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_954) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243143: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 243143, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243151:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___GEN_290) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_cfi_type))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_964)) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"about to abort: [fetch] JAL is followed by the wrong instruction. 0x%x =/= 0x%x\n",
                       39,vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_962,
                       39,(VL_ULL(0x7fffffffff) & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_target 
                                                   >> 1U)));
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243162:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___GEN_290) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_cfi_type))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_964)) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"fetch_pc: 0x%x, last_target: 0x%x, last_nextlinepc: 0x%x\n",
                       40,vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__q_f3_imemresp__DOT___T_2_0_pc,
                       40,vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_target,
                       40,vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_nextlinepc);
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243173:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___GEN_290) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_cfi_type))) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_969) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fetch] JAL is followed by the wrong instruction.\n    at fetch-control-unit.scala:664 assert (f_pc === targ, \"[fetch] JAL is followed by the wrong instruction.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243184:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___GEN_290) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_cfi_type))) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_969) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243187: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 243187, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243195:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___GEN_310) 
                           & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_cfi_type))) 
                          & ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_964) 
                             & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__q_f3_imemresp__DOT___T_2_0_pc 
                                != vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_nextlinepc))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"about to abort: [fetch] Branch is followed by the wrong instruction\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243206:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___GEN_310) 
                           & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_cfi_type))) 
                          & ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_964) 
                             & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__q_f3_imemresp__DOT___T_2_0_pc 
                                != vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_nextlinepc))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"0x%x =/= 0x%x, 0x%x =/= 0x%x\n",
                       39,vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_962,
                       39,(VL_ULL(0x7fffffffff) & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_target 
                                                   >> 1U)),
                       40,vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__q_f3_imemresp__DOT___T_2_0_pc,
                       40,vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_nextlinepc);
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243217:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___GEN_310) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_cfi_type))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_990))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fetch] branch is followed by the wrong instruction.\n    at fetch-control-unit.scala:674 assert (fetch_pc === last_nextlinepc || f_pc === targ,\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243228:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___GEN_310) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_cfi_type))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_990))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243231: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 243231, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243239:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___GEN_310) 
                          & (1U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_cfi_type))) 
                         & (~ ((3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_cfi_type)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fetch] Should be a JALR if none of the others were valid.\n    at fetch-control-unit.scala:678 assert (last_cfi_type === CFI_JALR, \"[fetch] Should be a JALR if none of the others were valid.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243250:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___GEN_310) 
                          & (1U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_cfi_type))) 
                         & (~ ((3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__last_cfi_type)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243253: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 243253, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243261:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_902) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_1055))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fetch] JAL was not taken.\n    at fetch-control-unit.scala:701 assert (!(has_jal && f3_jal_idx < cfi_idx), \"[fetch] JAL was not taken.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243272:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_902) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_1055))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243275: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 243275, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243283:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_1059))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at fetch-control-unit.scala:705 assert(q_f3_imemresp.io.deq.valid === q_f3_btb_resp.io.deq.valid)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243294:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_1059))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243297: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 243297, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243327:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_1067))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at fetch-control-unit.scala:707 assert(q_f3_imemresp.io.deq.ready === q_f3_btb_resp.io.deq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243338:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_1067))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243341: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 243341, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243349:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_1071))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at fetch-control-unit.scala:708 assert(q_f3_imemresp.io.enq.ready === q_f3_btb_resp.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243360:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT___T_1071))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:243363: Assertion failed in %NTestHarness.top.boom_tile.frontend.fetch_controller\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 243363, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__3115(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__3115\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:289934:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT__fdivsqrt__DOT___T_143))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fdiv] a request is incoming while the buffer is already full.\n    at fdiv.scala:134 assert (!(r_buffer_val && io.req.valid), \"[fdiv] a request is incoming while the buffer is already full.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:289945:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT__fdivsqrt__DOT___T_143))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:289948: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fpiu_unit.fdivsqrt\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 289948, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:289956:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT__fdivsqrt__DOT___T_178) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT__fdivsqrt__DOT__r_divsqrt_val) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fdiv] a response is being generated for no request.\n    at fdiv.scala:201 assert (r_divsqrt_val, \"[fdiv] a response is being generated for no request.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:289967:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT__fdivsqrt__DOT___T_178) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT__fdivsqrt__DOT__r_divsqrt_val) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:289970: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fpiu_unit.fdivsqrt\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 289970, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:289978:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT__fdivsqrt__DOT___T_203))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fdiv] Buffered output being overwritten by another output from the fdiv/fsqrt unit.\n    at fdiv.scala:204 assert (!(r_out_val && (divsqrt.io.outValid_div || divsqrt.io.outValid_sqrt)),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:289989:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT__fdivsqrt__DOT___T_203))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:289992: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fpiu_unit.fdivsqrt\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 289992, "");
        }
    }
}
