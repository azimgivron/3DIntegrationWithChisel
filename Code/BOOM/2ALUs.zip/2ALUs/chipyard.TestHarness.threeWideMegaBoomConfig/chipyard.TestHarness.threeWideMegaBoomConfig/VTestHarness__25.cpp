// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VTestHarness.h for the primary calling header

#include "VTestHarness.h"
#include "VTestHarness__Syms.h"

#include "verilated_dpi.h"

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2604(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2604\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__fetch_controller__DOT__ftq__DOT__ftq_bundle_ram_fetch_pc__v0 = 0U;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2608(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2608\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__btb_tag_array__DOT__btb_tag_array_ext__DOT__mem_0_0__DOT__ram__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__btb_tag_array_1__DOT__btb_tag_array_ext__DOT__mem_0_0__DOT__ram__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__btb_tag_array_2__DOT__btb_tag_array_ext__DOT__mem_0_0__DOT__ram__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__btb_tag_array_3__DOT__btb_tag_array_ext__DOT__mem_0_0__DOT__ram__v0 = 0U;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__hella_state 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__hella_state;
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251062:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_251))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries AcquireBlock type unsupported by manager (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:51 assert (edge.manager.supportsAcquireBSafe(edge.address(bundle), bundle.size), \"'A' channel carries AcquireBlock type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251073:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_251))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251076: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251076, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251084:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_279))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries AcquireBlock from a client which does not support Probe (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:52 assert (edge.client.supportsProbe(edge.source(bundle), bundle.size), \"'A' channel carries AcquireBlock from a client which does not support Probe\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251095:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_279))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251098: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251098, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251106:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:53 assert (source_ok, \"'A' channel AcquireBlock carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251117:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251120: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251120, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251128:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((4U <= (0xfU & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                               >> 0x16U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock smaller than a beat (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:54 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'A' channel AcquireBlock smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251139:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((4U <= (0xfU & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                               >> 0x16U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251142: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251142, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251150:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:55 assert (is_aligned, \"'A' channel AcquireBlock address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251161:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251164: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251164, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251172:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((2U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock carries invalid grow param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:56 assert (TLPermissions.isGrow(bundle.param), \"'A' channel AcquireBlock carries invalid grow param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251183:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((2U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251186: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251186, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251194:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((0U == (0xffffU & (~ 
                                                  ((vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                                    << 0x1fU) 
                                                   | (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[4U] 
                                                      >> 1U))))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:57 assert (~bundle.mask === 0.U, \"'A' channel AcquireBlock contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251205:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((0U == (0xffffU & (~ 
                                                  ((vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                                    << 0x1fU) 
                                                   | (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[4U] 
                                                      >> 1U))))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251208: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251208, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251216:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:58 assert (!bundle.corrupt, \"'A' channel AcquireBlock is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251227:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251230: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251230, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251238:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_251))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries AcquirePerm type unsupported by manager (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:62 assert (edge.manager.supportsAcquireBSafe(edge.address(bundle), bundle.size), \"'A' channel carries AcquirePerm type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251249:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_251))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251252: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251252, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251260:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_279))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries AcquirePerm from a client which does not support Probe (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:63 assert (edge.client.supportsProbe(edge.source(bundle), bundle.size), \"'A' channel carries AcquirePerm from a client which does not support Probe\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251271:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_279))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251274: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251274, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251282:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:64 assert (source_ok, \"'A' channel AcquirePerm carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251293:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251296: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251296, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251304:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((4U <= (0xfU & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                               >> 0x16U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm smaller than a beat (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:65 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'A' channel AcquirePerm smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251315:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((4U <= (0xfU & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                               >> 0x16U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251318: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251318, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251326:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:66 assert (is_aligned, \"'A' channel AcquirePerm address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251337:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251340: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251340, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251348:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((2U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm carries invalid grow param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:67 assert (TLPermissions.isGrow(bundle.param), \"'A' channel AcquirePerm carries invalid grow param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251359:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((2U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251362: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251362, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251370:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((0U != (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm requests NtoB (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:68 assert (bundle.param =/= TLPermissions.NtoB, \"'A' channel AcquirePerm requests NtoB\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251381:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((0U != (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251384: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251384, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251392:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((0U == (0xffffU & (~ 
                                                  ((vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                                    << 0x1fU) 
                                                   | (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[4U] 
                                                      >> 1U))))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:69 assert (~bundle.mask === 0.U, \"'A' channel AcquirePerm contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251403:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((0U == (0xffffU & (~ 
                                                  ((vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                                    << 0x1fU) 
                                                   | (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[4U] 
                                                      >> 1U))))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251406: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251406, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251414:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:70 assert (!bundle.corrupt, \"'A' channel AcquirePerm is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251425:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251428: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251428, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251436:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_476))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries Get type unsupported by manager (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:74 assert (edge.manager.supportsGetSafe(edge.address(bundle), bundle.size), \"'A' channel carries Get type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251447:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_476))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251450: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251450, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251458:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:75 assert (source_ok, \"'A' channel Get carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251469:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251472: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251472, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251480:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:76 assert (is_aligned, \"'A' channel Get address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251491:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251494: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251494, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251502:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get carries invalid param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:77 assert (bundle.param === 0.U, \"'A' channel Get carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251513:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251516: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251516, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251524:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_490))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:78 assert (bundle.mask === mask, \"'A' channel Get contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251535:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_490))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251538: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251538, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251546:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:79 assert (!bundle.corrupt, \"'A' channel Get is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251557:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251560: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251560, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251568:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_558))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries PutFull type unsupported by manager (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:83 assert (edge.manager.supportsPutFullSafe(edge.address(bundle), bundle.size), \"'A' channel carries PutFull type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251579:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_558))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251582: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251582, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251590:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutFull carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:84 assert (source_ok, \"'A' channel PutFull carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251601:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251604: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251604, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251612:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutFull address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:85 assert (is_aligned, \"'A' channel PutFull address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251623:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251626: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251626, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251634:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutFull carries invalid param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:86 assert (bundle.param === 0.U, \"'A' channel PutFull carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251645:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251648: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251648, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251656:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_490))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutFull contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:87 assert (bundle.mask === mask, \"'A' channel PutFull contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251667:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_490))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251670: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251670, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251678:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_558))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries PutPartial type unsupported by manager (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:91 assert (edge.manager.supportsPutPartialSafe(edge.address(bundle), bundle.size), \"'A' channel carries PutPartial type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251689:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_558))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251692: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251692, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251700:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutPartial carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:92 assert (source_ok, \"'A' channel PutPartial carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251711:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251714: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251714, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251722:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutPartial address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:93 assert (is_aligned, \"'A' channel PutPartial address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251733:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251736: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251736, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251744:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutPartial carries invalid param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:94 assert (bundle.param === 0.U, \"'A' channel PutPartial carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251755:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251758: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251758, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251766:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_652))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutPartial contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:95 assert ((bundle.mask & ~mask) === 0.U, \"'A' channel PutPartial contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251777:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_652))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251780: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251780, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251788:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_716))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries Arithmetic type unsupported by manager (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:99 assert (edge.manager.supportsArithmeticSafe(edge.address(bundle), bundle.size), \"'A' channel carries Arithmetic type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251799:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_716))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251802: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251802, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251810:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Arithmetic carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:100 assert (source_ok, \"'A' channel Arithmetic carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251821:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251824: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251824, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251832:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Arithmetic address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:101 assert (is_aligned, \"'A' channel Arithmetic address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251843:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251846: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251846, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251854:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((4U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Arithmetic carries invalid opcode param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:102 assert (TLAtomics.isArithmetic(bundle.param), \"'A' channel Arithmetic carries invalid opcode param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251865:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((4U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251868: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251868, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251876:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_490))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Arithmetic contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:103 assert (bundle.mask === mask, \"'A' channel Arithmetic contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251887:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_490))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251890: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251890, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251898:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_716))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries Logical type unsupported by manager (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:107 assert (edge.manager.supportsLogicalSafe(edge.address(bundle), bundle.size), \"'A' channel carries Logical type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251909:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_716))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251912: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251912, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251920:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Logical carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:108 assert (source_ok, \"'A' channel Logical carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251931:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251934: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251934, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251942:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Logical address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:109 assert (is_aligned, \"'A' channel Logical address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251953:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251956: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251956, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251964:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((3U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Logical carries invalid opcode param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:110 assert (TLAtomics.isLogical(bundle.param), \"'A' channel Logical carries invalid opcode param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251975:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((3U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                             >> 0x1aU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251978: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 251978, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251986:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_490))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Logical contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:111 assert (bundle.mask === mask, \"'A' channel Logical contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:251997:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_490))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252000: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252000, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252008:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_872))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries Hint type unsupported by manager (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:115 assert (edge.manager.supportsHintSafe(edge.address(bundle), bundle.size), \"'A' channel carries Hint type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252019:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_872))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252022: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252022, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252030:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Hint carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:116 assert (source_ok, \"'A' channel Hint carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252041:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_282))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252044: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252044, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252052:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Hint address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:117 assert (is_aligned, \"'A' channel Hint address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252063:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_289))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252066: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252066, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252074:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_490))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Hint contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:118 assert (bundle.mask === mask, \"'A' channel Hint contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252085:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_490))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252088: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252088, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252096:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Hint is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:119 assert (!bundle.corrupt, \"'A' channel Hint is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252107:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[5U] 
                                          >> 0x1dU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar__DOT___T_240[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252110: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252110, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252118:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                               & (~ ((6U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data)) 
                                     | (IData)(vlTOPp->reset))))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel has invalid opcode (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:270 assert (TLMessages.isD(bundle.opcode), \"'D' channel has invalid opcode\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252129:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                               & (~ ((6U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data)) 
                                     | (IData)(vlTOPp->reset))))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252132: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252132, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252140:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_915))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel ReleaseAck carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:278 assert (source_ok, \"'D' channel ReleaseAck carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252151:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_915))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252154: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252154, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252162:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((4U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_size___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel ReleaseAck smaller than a beat (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:279 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'D' channel ReleaseAck smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252173:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((4U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_size___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252176: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252176, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252184:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel ReleaseeAck carries invalid param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:280 assert (bundle.param === 0.U, \"'D' channel ReleaseeAck carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252195:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252198: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252198, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252206:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_corrupt___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel ReleaseAck is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:281 assert (!bundle.corrupt, \"'D' channel ReleaseAck is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252217:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_corrupt___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252220: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252220, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252228:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_denied___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel ReleaseAck is denied (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:282 assert (!bundle.denied, \"'D' channel ReleaseAck is denied\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252239:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_denied___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252242: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252242, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252250:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_915))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:286 assert (source_ok, \"'D' channel Grant carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252261:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_915))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252264: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252264, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252272:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((4U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_size___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant smaller than a beat (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:288 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'D' channel Grant smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252283:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((4U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_size___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252286: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252286, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252294:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((2U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant carries invalid cap param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:289 assert (TLPermissions.isCap(bundle.param), \"'D' channel Grant carries invalid cap param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252305:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((2U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252308: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252308, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252316:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((2U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant carries toN param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:290 assert (bundle.param =/= TLPermissions.toN, \"'D' channel Grant carries toN param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252327:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((2U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252330: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252330, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252338:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_corrupt___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:291 assert (!bundle.corrupt, \"'D' channel Grant is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252349:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_corrupt___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252352: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252352, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252360:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_915))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:296 assert (source_ok, \"'D' channel GrantData carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252371:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_915))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252374: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252374, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252382:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((4U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_size___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData smaller than a beat (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:298 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'D' channel GrantData smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252393:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((4U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_size___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252396: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252396, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252404:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((2U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData carries invalid cap param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:299 assert (TLPermissions.isCap(bundle.param), \"'D' channel GrantData carries invalid cap param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252415:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((2U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252418: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252418, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252426:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((2U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData carries toN param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:300 assert (bundle.param =/= TLPermissions.toN, \"'D' channel GrantData carries toN param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252437:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((2U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252440: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252440, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252448:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_983))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData is denied but not corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:301 assert (!bundle.denied || bundle.corrupt, \"'D' channel GrantData is denied but not corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252459:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_983))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252462: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252462, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252470:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_915))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAck carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:306 assert (source_ok, \"'D' channel AccessAck carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252481:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_915))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252484: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252484, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252492:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAck carries invalid param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:308 assert (bundle.param === 0.U, \"'D' channel AccessAck carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252503:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252506: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252506, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252514:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_corrupt___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAck is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:309 assert (!bundle.corrupt, \"'D' channel AccessAck is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252525:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_corrupt___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252528: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252528, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252536:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_915))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAckData carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:314 assert (source_ok, \"'D' channel AccessAckData carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252547:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_915))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252550: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252550, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252558:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAckData carries invalid param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:316 assert (bundle.param === 0.U, \"'D' channel AccessAckData carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252569:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252572: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252572, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252580:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_983))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAckData is denied but not corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:317 assert (!bundle.denied || bundle.corrupt, \"'D' channel AccessAckData is denied but not corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252591:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_983))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252594: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252594, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252602:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_915))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel HintAck carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:322 assert (source_ok, \"'D' channel HintAck carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252613:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_915))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252616: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252616, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252624:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel HintAck carries invalid param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:324 assert (bundle.param === 0.U, \"'D' channel HintAck carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252635:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252638: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252638, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252646:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_corrupt___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel HintAck is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:325 assert (!bundle.corrupt, \"'D' channel HintAck is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252657:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_corrupt___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252660: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252660, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252668:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                               & (~ ((6U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data)) 
                                     | (IData)(vlTOPp->reset))))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel has invalid opcode (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:124 assert (TLMessages.isB(bundle.opcode), \"'B' channel has invalid opcode\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252679:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                               & (~ ((6U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data)) 
                                     | (IData)(vlTOPp->reset))))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252682: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252682, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252690:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1318))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel carries Probe type unsupported by client (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:135 assert (edge.client.supportsProbe(bundle.source, bundle.size), \"'B' channel carries Probe type unsupported by client\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252701:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1318))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252704: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252704, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252712:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1321))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Probe carries unmanaged address (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:136 assert (address_ok, \"'B' channel Probe carries unmanaged address\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252723:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1321))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252726: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252726, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252734:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1324))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Probe carries source that is not first source (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:137 assert (legal_source, \"'B' channel Probe carries source that is not first source\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252745:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1324))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252748: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252748, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252756:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1327))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Probe address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:138 assert (is_aligned, \"'B' channel Probe address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252767:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1327))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252770: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252770, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252778:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((2U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Probe carries invalid cap param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:139 assert (TLPermissions.isCap(bundle.param), \"'B' channel Probe carries invalid cap param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252789:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((2U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252792: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252792, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252800:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1335))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Probe contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:140 assert (bundle.mask === mask, \"'B' channel Probe contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252811:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1335))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252814: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252814, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252822:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_corrupt
                                [vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT__value_1]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Probe is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:141 assert (!bundle.corrupt, \"'B' channel Probe is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252833:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_corrupt
                                [vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT__value_1]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252836: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252836, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252844:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel carries Get type unsupported by client (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:145 assert (edge.client.supportsGet(bundle.source, bundle.size), \"'B' channel carries Get type unsupported by client\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252855:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252858: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252858, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252866:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1321))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Get carries unmanaged address (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:146 assert (address_ok, \"'B' channel Get carries unmanaged address\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252877:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1321))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252880: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252880, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252888:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1324))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Get carries source that is not first source (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:147 assert (legal_source, \"'B' channel Get carries source that is not first source\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252899:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1324))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252902: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252902, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252910:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1327))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Get address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:148 assert (is_aligned, \"'B' channel Get address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252921:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1327))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252924: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252924, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252932:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Get carries invalid param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:149 assert (bundle.param === 0.U, \"'B' channel Get carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252943:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252946: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252946, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252954:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1335))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Get contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:150 assert (bundle.mask === mask, \"'B' channel Get contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252965:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1335))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252968: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252968, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252976:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_corrupt
                                [vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT__value_1]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Get is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:151 assert (!bundle.corrupt, \"'B' channel Get is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252987:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_corrupt
                                [vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT__value_1]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252990: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 252990, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:252998:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel carries PutFull type unsupported by client (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:155 assert (edge.client.supportsPutFull(bundle.source, bundle.size), \"'B' channel carries PutFull type unsupported by client\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253009:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253012: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253012, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253020:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1321))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel PutFull carries unmanaged address (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:156 assert (address_ok, \"'B' channel PutFull carries unmanaged address\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253031:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1321))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253034: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253034, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253042:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1324))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel PutFull carries source that is not first source (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:157 assert (legal_source, \"'B' channel PutFull carries source that is not first source\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253053:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1324))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253056: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253056, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253064:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1327))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel PutFull address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:158 assert (is_aligned, \"'B' channel PutFull address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253075:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1327))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253078: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253078, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253086:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel PutFull carries invalid param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:159 assert (bundle.param === 0.U, \"'B' channel PutFull carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253097:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253100: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253100, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253108:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1335))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel PutFull contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:160 assert (bundle.mask === mask, \"'B' channel PutFull contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253119:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1335))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253122: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253122, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253130:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel carries PutPartial type unsupported by client (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:164 assert (edge.client.supportsPutPartial(bundle.source, bundle.size), \"'B' channel carries PutPartial type unsupported by client\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253141:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253144: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253144, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253152:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1321))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel PutPartial carries unmanaged address (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:165 assert (address_ok, \"'B' channel PutPartial carries unmanaged address\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253163:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1321))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253166: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253166, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253174:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1324))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel PutPartial carries source that is not first source (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:166 assert (legal_source, \"'B' channel PutPartial carries source that is not first source\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253185:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1324))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253188: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253188, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253196:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1327))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel PutPartial address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:167 assert (is_aligned, \"'B' channel PutPartial address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253207:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1327))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253210: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253210, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253218:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel PutPartial carries invalid param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:168 assert (bundle.param === 0.U, \"'B' channel PutPartial carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253229:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253232: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253232, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253240:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1408))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel PutPartial contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:169 assert ((bundle.mask & ~mask) === 0.U, \"'B' channel PutPartial contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253251:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1408))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253254: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253254, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253262:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel carries Arithmetic type unsupported by client (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:173 assert (edge.client.supportsArithmetic(bundle.source, bundle.size), \"'B' channel carries Arithmetic type unsupported by client\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253273:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253276: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253276, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253284:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1321))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Arithmetic carries unmanaged address (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:174 assert (address_ok, \"'B' channel Arithmetic carries unmanaged address\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253295:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1321))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253298: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253298, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253306:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1324))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Arithmetic carries source that is not first source (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:175 assert (legal_source, \"'B' channel Arithmetic carries source that is not first source\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253317:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1324))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253320: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253320, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253328:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1327))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Arithmetic address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:176 assert (is_aligned, \"'B' channel Arithmetic address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253339:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1327))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253342: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253342, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253350:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1335))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Arithmetic contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:178 assert (bundle.mask === mask, \"'B' channel Arithmetic contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253361:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1335))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253364: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253364, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253372:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel carries Logical type unsupported by client (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:182 assert (edge.client.supportsLogical(bundle.source, bundle.size), \"'B' channel carries Logical type unsupported by client\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253383:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253386: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253386, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253394:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1321))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Logical carries unmanaged address (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:183 assert (address_ok, \"'B' channel Logical carries unmanaged address\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253405:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1321))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253408: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253408, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253416:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1324))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Logical carries source that is not first source (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:184 assert (legal_source, \"'B' channel Logical carries source that is not first source\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253427:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1324))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253430: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253430, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253438:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1327))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Logical address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:185 assert (is_aligned, \"'B' channel Logical address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253449:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1327))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253452: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253452, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253460:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1335))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Logical contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:187 assert (bundle.mask === mask, \"'B' channel Logical contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253471:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1335))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253474: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253474, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253482:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel carries Hint type unsupported by client (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:191 assert (edge.client.supportsHint(bundle.source, bundle.size), \"'B' channel carries Hint type unsupported by client\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253493:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253496: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253496, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253504:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1321))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Hint carries unmanaged address (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:192 assert (address_ok, \"'B' channel Hint carries unmanaged address\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253515:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1321))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253518: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253518, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253526:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1324))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Hint carries source that is not first source (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:193 assert (legal_source, \"'B' channel Hint carries source that is not first source\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253537:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1324))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253540: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253540, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253548:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1327))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Hint address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:194 assert (is_aligned, \"'B' channel Hint address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253559:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1327))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253562: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253562, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253570:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1335))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Hint contains invalid mask (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:195 assert (bundle.mask === mask, \"'B' channel Hint contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253581:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1335))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253584: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253584, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253592:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_corrupt
                                [vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT__value_1]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel Hint is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:196 assert (!bundle.corrupt, \"'B' channel Hint is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253603:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_opcode___05FT_18_data))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_corrupt
                                [vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT__value_1]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253606: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253606, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253614:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1596))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ProbeAck carries unmanaged address (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:210 assert (address_ok, \"'C' channel ProbeAck carries unmanaged address\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253625:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1596))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253628: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253628, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253636:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1599))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ProbeAck carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:211 assert (source_ok, \"'C' channel ProbeAck carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253647:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1599))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253650: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253650, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253658:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((4U <= (0xfU & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                               >> 5U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ProbeAck smaller than a beat (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:212 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'C' channel ProbeAck smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253669:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((4U <= (0xfU & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                               >> 5U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253672: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253672, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253680:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1606))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ProbeAck address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:213 assert (is_aligned, \"'C' channel ProbeAck address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253691:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1606))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253694: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253694, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253702:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((5U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                             >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ProbeAck carries invalid report param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:214 assert (TLPermissions.isReport(bundle.param), \"'C' channel ProbeAck carries invalid report param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253713:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((5U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                             >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253716: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253716, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253724:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ProbeAck is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:215 assert (!bundle.corrupt, \"'C' channel ProbeAck is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253735:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253738: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253738, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253746:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1596))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ProbeAckData carries unmanaged address (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:219 assert (address_ok, \"'C' channel ProbeAckData carries unmanaged address\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253757:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1596))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253760: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253760, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253768:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1599))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ProbeAckData carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:220 assert (source_ok, \"'C' channel ProbeAckData carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253779:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1599))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253782: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253782, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253790:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((4U <= (0xfU & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                               >> 5U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ProbeAckData smaller than a beat (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:221 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'C' channel ProbeAckData smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253801:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((4U <= (0xfU & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                               >> 5U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253804: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253804, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253812:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1606))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ProbeAckData address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:222 assert (is_aligned, \"'C' channel ProbeAckData address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253823:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1606))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253826: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253826, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253834:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((5U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                             >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ProbeAckData carries invalid report param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:223 assert (TLPermissions.isReport(bundle.param), \"'C' channel ProbeAckData carries invalid report param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253845:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((5U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                             >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253848: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253848, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253856:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1689))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel carries Release type unsupported by manager (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:227 assert (edge.manager.supportsAcquireBSafe(edge.address(bundle), bundle.size), \"'C' channel carries Release type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253867:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1689))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253870: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253870, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253878:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1717))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel carries Release from a client which does not support Probe (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:228 assert (edge.client.supportsProbe(edge.source(bundle), bundle.size), \"'C' channel carries Release from a client which does not support Probe\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253889:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1717))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253892: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253892, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253900:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1599))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel Release carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:229 assert (source_ok, \"'C' channel Release carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253911:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1599))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253914: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253914, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253922:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((4U <= (0xfU & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                               >> 5U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel Release smaller than a beat (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:230 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'C' channel Release smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253933:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((4U <= (0xfU & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                               >> 5U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253936: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253936, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253944:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1606))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel Release address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:231 assert (is_aligned, \"'C' channel Release address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253955:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1606))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253958: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253958, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253966:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((2U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                             >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel Release carries invalid shrink param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:232 assert (TLPermissions.isShrink(bundle.param), \"'C' channel Release carries invalid shrink param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253977:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((2U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                             >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253980: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 253980, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253988:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel Release is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:233 assert (!bundle.corrupt, \"'C' channel Release is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:253999:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254002: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254002, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254010:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1689))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel carries ReleaseData type unsupported by manager (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:237 assert (edge.manager.supportsAcquireBSafe(edge.address(bundle), bundle.size), \"'C' channel carries ReleaseData type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254021:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1689))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254024: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254024, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254032:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1717))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel carries Release from a client which does not support Probe (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:238 assert (edge.client.supportsProbe(edge.source(bundle), bundle.size), \"'C' channel carries Release from a client which does not support Probe\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254043:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1717))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254046: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254046, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254054:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1599))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ReleaseData carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:239 assert (source_ok, \"'C' channel ReleaseData carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254065:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1599))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254068: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254068, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254076:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((4U <= (0xfU & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                               >> 5U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ReleaseData smaller than a beat (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:240 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'C' channel ReleaseData smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254087:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((4U <= (0xfU & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                               >> 5U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254090: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254090, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254098:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1606))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ReleaseData address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:241 assert (is_aligned, \"'C' channel ReleaseData address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254109:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1606))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254112: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254112, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254120:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((2U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                             >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel ReleaseData carries invalid shrink param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:242 assert (TLPermissions.isShrink(bundle.param), \"'C' channel ReleaseData carries invalid shrink param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254131:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((2U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                             >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254134: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254134, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254142:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1596))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel AccessAck carries unmanaged address (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:246 assert (address_ok, \"'C' channel AccessAck carries unmanaged address\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254153:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1596))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254156: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254156, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254164:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1599))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel AccessAck carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:247 assert (source_ok, \"'C' channel AccessAck carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254175:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1599))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254178: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254178, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254186:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1606))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel AccessAck address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:248 assert (is_aligned, \"'C' channel AccessAck address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254197:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1606))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254200: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254200, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254208:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                             >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel AccessAck carries invalid param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:249 assert (bundle.param === 0.U, \"'C' channel AccessAck carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254219:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                             >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254222: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254222, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254230:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel AccessAck is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:250 assert (!bundle.corrupt, \"'C' channel AccessAck is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254241:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254244: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254244, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254252:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1596))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel AccessAckData carries unmanaged address (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:254 assert (address_ok, \"'C' channel AccessAckData carries unmanaged address\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254263:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1596))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254266: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254266, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254274:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1599))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel AccessAckData carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:255 assert (source_ok, \"'C' channel AccessAckData carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254285:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1599))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254288: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254288, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254296:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1606))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel AccessAckData address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:256 assert (is_aligned, \"'C' channel AccessAckData address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254307:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1606))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254310: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254310, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254318:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                             >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel AccessAckData carries invalid param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:257 assert (bundle.param === 0.U, \"'C' channel AccessAckData carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254329:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                             >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254332: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254332, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254340:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1596))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel HintAck carries unmanaged address (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:261 assert (address_ok, \"'C' channel HintAck carries unmanaged address\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254351:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1596))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254354: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254354, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254362:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1599))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel HintAck carries invalid source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:262 assert (source_ok, \"'C' channel HintAck carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254373:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1599))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254376: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254376, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254384:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1606))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel HintAck address not aligned to size (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:263 assert (is_aligned, \"'C' channel HintAck address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254395:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1606))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254398: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254398, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254406:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                             >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel HintAck carries invalid param (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:264 assert (bundle.param === 0.U, \"'C' channel HintAck carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254417:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                             >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254420: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254420, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254428:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel HintAck is corrupt (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:265 assert (!bundle.corrupt, \"'C' channel HintAck is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254439:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[5U] 
                                          >> 0xcU)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_1052[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254442: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254442, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254450:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1899))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1919))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel opcode changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:357 assert (a.bits.opcode === opcode, \"'A' channel opcode changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254461:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1899))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1919))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254464: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254464, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254472:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1899))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1923))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel param changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:358 assert (a.bits.param  === param,  \"'A' channel param changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254483:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1899))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1923))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254486: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254486, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254494:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1899))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1927))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel size changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:359 assert (a.bits.size   === size,   \"'A' channel size changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254505:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1899))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1927))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254508: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254508, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254516:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1899))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1931))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel source changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:360 assert (a.bits.source === source, \"'A' channel source changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254527:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1899))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1931))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254530: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254530, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254538:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1899))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1935))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel address changed with multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:361 assert (a.bits.address=== address,\"'A' channel address changed with multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254549:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__tlMasterXbar_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1899))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1935))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254552: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254552, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254560:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1947))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1968))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel opcode changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:427 assert (d.bits.opcode === opcode, \"'D' channel opcode changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254571:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1947))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1968))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254574: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254574, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254582:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1947))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1972))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel param changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:428 assert (d.bits.param  === param,  \"'D' channel param changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254593:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1947))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1972))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254596: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254596, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254604:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1947))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1976))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel size changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:429 assert (d.bits.size   === size,   \"'D' channel size changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254615:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1947))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1976))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254618: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254618, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254626:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1947))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1980))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel source changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:430 assert (d.bits.source === source, \"'D' channel source changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254637:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1947))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1980))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254640: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254640, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254648:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1947))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1984))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel sink changed with multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:431 assert (d.bits.sink   === sink,   \"'D' channel sink changed with multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254659:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1947))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1984))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254662: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254662, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254670:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1947))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1988))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel denied changed with multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:432 assert (d.bits.denied === denied, \"'D' channel denied changed with multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254681:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1947))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1988))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254684: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254684, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254692:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2001))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2021))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel opcode changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:380 assert (b.bits.opcode === opcode, \"'B' channel opcode changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254703:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2001))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2021))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254706: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254706, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254714:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2001))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2025))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel param changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:381 assert (b.bits.param  === param,  \"'B' channel param changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254725:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2001))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2025))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254728: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254728, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254736:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2001))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2029))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel size changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:382 assert (b.bits.size   === size,   \"'B' channel size changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254747:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2001))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2029))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254750: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254750, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254758:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2001))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2033))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel source changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:383 assert (b.bits.source === source, \"'B' channel source changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254769:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2001))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2033))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254772: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254772, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254780:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2001))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2037))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'B' channel addresss changed with multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:384 assert (b.bits.address=== address,\"'B' channel addresss changed with multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254791:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_2__DOT___T_4)) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2001))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2037))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254794: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254794, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254802:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2049))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2069))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel opcode changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:403 assert (c.bits.opcode === opcode, \"'C' channel opcode changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254813:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2049))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2069))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254816: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254816, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254824:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2049))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2073))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel param changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:404 assert (c.bits.param  === param,  \"'C' channel param changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254835:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2049))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2073))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254838: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254838, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254846:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2049))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2077))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel size changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:405 assert (c.bits.size   === size,   \"'C' channel size changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254857:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2049))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2077))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254860: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254860, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254868:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2049))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2081))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel source changed within multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:406 assert (c.bits.source === source, \"'C' channel source changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254879:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2049))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2081))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254882: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254882, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254890:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2049))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2085))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'C' channel address changed with multibeat operation (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:407 assert (c.bits.address=== address,\"'C' channel address changed with multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254901:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache_auto_out_c_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2049))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2085))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254904: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254904, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254912:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1890) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2099))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2138))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel re-used a source ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:462 assert(!inflight(bundle.a.bits.source), \"'A' channel re-used a source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254923:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1890) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2099))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2138))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254926: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254926, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254934:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1939) 
                           & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2118))) 
                          & (6U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2152))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel acknowledged for nothing inflight (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:469 assert((a_set | inflight)(bundle.d.bits.source), \"'D' channel acknowledged for nothing inflight\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254945:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1939) 
                           & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2118))) 
                          & (6U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2152))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254948: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254948, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254956:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2159))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' and 'D' concurrent, despite minlatency 4 (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:473 assert(a_set =/= d_clr || !a_set.orR, s\"'A' and 'D' concurrent, despite minlatency ${edge.manager.minLatency}\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254967:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2159))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254970: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254970, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254978:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2172))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: TileLink timeout expired (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:481 assert (!inflight.orR || limit === 0.U || watchdog < limit, \"TileLink timeout expired\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254989:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2172))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:254992: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 254992, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:255000:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1939) 
                           & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2188))) 
                          & (((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data) 
                              >> 2U) & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data) 
                                           >> 1U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2212))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel re-used a sink ID (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:496 assert(!inflight(bundle.d.bits.sink), \"'D' channel re-used a sink ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:255011:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_1939) 
                           & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2188))) 
                          & (((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data) 
                              >> 2U) & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode___05FT_18_data) 
                                           >> 1U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2212))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:255014: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 255014, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:255022:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_4__DOT___T_5)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs_io_mem_finish_valid)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2223))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'E' channel acknowledged for nothing inflight (connected at CrossingHelper.scala:30:80)\n    at Monitor.scala:502 assert((d_set | inflight)(bundle.e.bits.sink), \"'E' channel acknowledged for nothing inflight\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:255033:11
done_reset        
    ) {
        if (VL_UNLIKELY((((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_4__DOT___T_5)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs_io_mem_finish_valid)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__TLMonitor__DOT___T_2223))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:255036: Assertion failed in %NTestHarness.top.boom_tile.buffer.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 255036, "");
        }
    }
}
