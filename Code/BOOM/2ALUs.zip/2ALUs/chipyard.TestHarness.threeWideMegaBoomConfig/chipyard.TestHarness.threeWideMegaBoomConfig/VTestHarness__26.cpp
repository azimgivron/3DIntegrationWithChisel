// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VTestHarness.h for the primary calling header

#include "VTestHarness.h"
#include "VTestHarness__Syms.h"

#include "verilated_dpi.h"

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2609(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2609\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__prober__DOT__req_address 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__prober__DOT__req_address;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_983 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT___T_983;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__wb__DOT__r1_data_req_cnt 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__wb__DOT__r1_data_req_cnt;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__wb__DOT__state 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__wb__DOT__state;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2610(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2610\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[1U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[1U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[2U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[2U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[3U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[3U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[4U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[4U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[5U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[5U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[6U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[6U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[7U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[7U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[8U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[8U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[9U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[9U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0xaU] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0xaU];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0xbU] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0xbU];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0xcU] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0xcU];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0xdU] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0xdU];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0xeU] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0xeU];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0xfU] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0xfU];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x10U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x10U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x11U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x11U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x12U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x12U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x13U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x13U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x14U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x14U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x15U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x15U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x16U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x16U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x17U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x17U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x18U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x18U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x19U] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x19U];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x1aU] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x1aU];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x1bU] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x1bU];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x1cU] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x1cU];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x1dU] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x1dU];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x1eU] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x1eU];
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x1fU] 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__ptw__DOT__valid_1[0x1fU];
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_corrupt__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_size__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_param__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_sink__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_denied__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_data__v0 = 0U;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__wb__DOT__req_idx 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__wb__DOT__req_idx;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2611(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2611\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_opcode__v0 = 0U;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2612(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2612\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__btb_data_array__DOT__btb_data_array_ext__DOT__mem_0_0__DOT__ram__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__btb_data_array_1__DOT__btb_data_array_ext__DOT__mem_0_0__DOT__ram__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__btb_data_array_2__DOT__btb_data_array_ext__DOT__mem_0_0__DOT__ram__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__btb_data_array_3__DOT__btb_data_array_ext__DOT__mem_0_0__DOT__ram__v0 = 0U;
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700719:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_4))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Can't have a mispredict during rollback.\n    at core.scala:181 assert (!(br_unit.brinfo.mispredict && rob.io.commit.rollback), \"Can't have a mispredict during rollback.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700730:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_4))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700733: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 700733, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700741:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_275))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at core.scala:676 assert(!(resp.valid && resp.bits.uop.rf_wen && resp.bits.uop.dst_rtype =/= RT_FIX))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700752:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_275))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700755: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 700755, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700763:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_299))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at core.scala:676 assert(!(resp.valid && resp.bits.uop.rf_wen && resp.bits.uop.dst_rtype =/= RT_FIX))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700774:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_299))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700777: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 700777, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700785:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_413))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fppipeline] An FP writeback is being attempted to the Int Regfile.\n    at core.scala:971 assert (!wbIsValid(RT_FLT), \"[fppipeline] An FP writeback is being attempted to the Int Regfile.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700796:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_413))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700799: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 700799, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700807:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_422))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fppipeline] An Int writeback is being attempted with rf_wen disabled.\n    at core.scala:973 assert (!(wbresp.valid &&\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700818:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_422))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700821: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 700821, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700829:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_275))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fppipeline] writeback being attempted to Int RF with dst != Int type exe_units(1).iresp\n    at core.scala:978 assert (!(wbresp.valid &&\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700840:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_275))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700843: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 700843, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700851:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_444))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fppipeline] An FP writeback is being attempted to the Int Regfile.\n    at core.scala:971 assert (!wbIsValid(RT_FLT), \"[fppipeline] An FP writeback is being attempted to the Int Regfile.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700862:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_444))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700865: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 700865, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700873:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_453))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fppipeline] An Int writeback is being attempted with rf_wen disabled.\n    at core.scala:973 assert (!(wbresp.valid &&\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700884:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_453))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700887: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 700887, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700895:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_299))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [fppipeline] writeback being attempted to Int RF with dst != Int type exe_units(2).iresp\n    at core.scala:978 assert (!(wbresp.valid &&\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700906:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_299))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700909: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 700909, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700917:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_491))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [core] FP wakeup does not write back to a FP register.\n    at core.scala:1060 assert (!(wakeup.valid && wakeup.bits.uop.dst_rtype =/= RT_FLT),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700928:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_491))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700931: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 700931, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700939:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_497))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [core] FP wakeup does not involve an FP instruction.\n    at core.scala:1063 assert (!(wakeup.valid && !wakeup.bits.uop.fp_val),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700950:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_497))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700953: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 700953, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700961:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_503))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [core] FP wakeup does not write back to a FP register.\n    at core.scala:1060 assert (!(wakeup.valid && wakeup.bits.uop.dst_rtype =/= RT_FLT),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700972:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_503))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700975: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 700975, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700983:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_509))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [core] FP wakeup does not involve an FP instruction.\n    at core.scala:1063 assert (!(wakeup.valid && !wakeup.bits.uop.fp_val),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700994:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_509))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:700997: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 700997, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:701005:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__csr_io_singleStep)) 
                                  | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [core] single-step is unsupported.\n    at core.scala:1087 assert (!(csr.io.singleStep), \"[core] single-step is unsupported.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:701016:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__csr_io_singleStep)) 
                                  | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:701019: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 701019, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:701027:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_520))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: [core] exception occurred, but pipeline flush signal not set!\n    at core.scala:1104 assert (!(RegNext(rob.io.com_xcpt.valid) && !rob.io.flush.valid),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:701038:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_520))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:701041: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 701041, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:701049:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ ((~ (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_524 
                                      >> 8U)) | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Pipeline has hung.\n    at core.scala:1121 assert (!(idle_cycles.value(13)), \"Pipeline has hung.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:701060:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ ((~ (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_524 
                                      >> 8U)) | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:701063: Assertion failed in %NTestHarness.top.boom_tile.core\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 701063, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2613(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2613\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__rpq__DOT__ram_addr__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__rpq__DOT__ram_addr__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__rpq__DOT__ram_addr__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__rpq__DOT__ram_addr__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__rpq__DOT__ram_addr__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__rpq__DOT__ram_addr__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__ram_addr__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__ram_addr__v0 = 0U;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__buffer__DOT__Queue_1__DOT___T_source__v0 = 0U;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__req_addr 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__req_addr;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__req_addr 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__req_addr;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__req_addr 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__req_addr;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__req_addr 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__req_addr;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__req_addr 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__req_addr;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2614(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2614\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__req_addr 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__req_addr;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__req_addr 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__req_addr;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__req_addr 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__req_addr;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__prober__DOT__way_en 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__prober__DOT__way_en;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2616(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2616\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:711076:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__dtlb_io_sfence_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__dtlb__DOT___T_2450))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at tlb.scala:338 assert(!io.sfence.bits.rs1 || (io.sfence.bits.addr >> pgIdxBits) === vpn(w))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:711087:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__dtlb_io_sfence_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu__DOT__dtlb__DOT___T_2450))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:711090: Assertion failed in %NTestHarness.top.boom_tile.lsu.dtlb\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 711090, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2617(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2617\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:197909:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_109) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__tlb__DOT___T_2379))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at TLB.scala:368 assert(!io.sfence.bits.rs1 || (io.sfence.bits.addr >> pgIdxBits) === vpn)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:197920:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT___T_109) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__tlb__DOT___T_2379))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:197923: Assertion failed in %NTestHarness.top.boom_tile.frontend.tlb\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 197923, "");
        }
    }
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__sdq__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__rpq__DOT__ram_is_hella__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__rpq__DOT__ram_is_hella__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__rpq__DOT__ram_is_hella__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__rpq__DOT__ram_is_hella__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__rpq__DOT__ram_is_hella__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__rpq__DOT__ram_is_hella__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__ram_is_hella__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__ram_is_hella__v0 = 0U;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2619(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2619\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:181436:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT___T_579))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at Arbiter.scala:68 assert((prefixOR zip winner) map { case (p,w) => !p || !w } reduce {_ && _})\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:181447:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT___T_579))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:181450: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 181450, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:181458:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT___T_600))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at Arbiter.scala:70 assert (!valids.reduce(_||_) || winner.reduce(_||_))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:181469:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT___T_600))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:181472: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 181472, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:181480:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT___T_834))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at Arbiter.scala:68 assert((prefixOR zip winner) map { case (p,w) => !p || !w } reduce {_ && _})\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:181491:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT___T_834))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:181494: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 181494, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:181502:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT___T_853))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at Arbiter.scala:70 assert (!valids.reduce(_||_) || winner.reduce(_||_))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:181513:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT___T_853))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:181516: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 181516, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2620(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2620\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174624:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_615))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:131 assert(!(state === s_invalid && !rpq.io.empty))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174635:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_615))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174638: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174638, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174646:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174657:11
done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174660: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174660, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174668:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174679:11
done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174682: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174682, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174690:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_1022))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:240 assert(!(!grant_had_data && req_needs_wb))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174701:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_1022))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174704: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174704, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174712:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_1377))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: We still don't have permissions for this store\n    at mshrs.scala:346 assert(is_hit, \"We still don't have permissions for this store\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174723:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_1377))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174726: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174726, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174734:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174745:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174748: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174748, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174756:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174767:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_7__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174770: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_7\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174770, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2621(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2621\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174624:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_615))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:131 assert(!(state === s_invalid && !rpq.io.empty))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174635:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_615))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174638: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174638, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174646:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174657:11
done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174660: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174660, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174668:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174679:11
done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174682: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174682, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174690:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_1022))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:240 assert(!(!grant_had_data && req_needs_wb))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174701:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_1022))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174704: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174704, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174712:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_1377))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: We still don't have permissions for this store\n    at mshrs.scala:346 assert(is_hit, \"We still don't have permissions for this store\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174723:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_1377))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174726: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174726, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174734:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174745:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174748: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174748, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174756:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174767:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_6__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174770: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_6\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174770, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2622(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2622\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174624:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_615))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:131 assert(!(state === s_invalid && !rpq.io.empty))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174635:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_615))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174638: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174638, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174646:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174657:11
done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174660: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174660, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174668:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174679:11
done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174682: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174682, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174690:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_1022))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:240 assert(!(!grant_had_data && req_needs_wb))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174701:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_1022))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174704: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174704, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174712:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_1377))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: We still don't have permissions for this store\n    at mshrs.scala:346 assert(is_hit, \"We still don't have permissions for this store\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174723:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_1377))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174726: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174726, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174734:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174745:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174748: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174748, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174756:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174767:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_5__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174770: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_5\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174770, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2623(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2623\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174624:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_615))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:131 assert(!(state === s_invalid && !rpq.io.empty))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174635:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_615))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174638: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174638, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174646:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174657:11
done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174660: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174660, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174668:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174679:11
done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174682: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174682, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174690:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_1022))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:240 assert(!(!grant_had_data && req_needs_wb))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174701:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_1022))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174704: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174704, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174712:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_1377))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: We still don't have permissions for this store\n    at mshrs.scala:346 assert(is_hit, \"We still don't have permissions for this store\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174723:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_1377))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174726: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174726, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174734:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174745:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174748: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174748, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174756:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174767:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_4__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174770: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_4\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174770, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2624(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2624\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174624:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_615))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:131 assert(!(state === s_invalid && !rpq.io.empty))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174635:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_615))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174638: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174638, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174646:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174657:11
done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174660: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174660, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174668:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174679:11
done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174682: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174682, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174690:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_1022))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:240 assert(!(!grant_had_data && req_needs_wb))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174701:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_1022))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174704: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174704, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174712:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_1377))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: We still don't have permissions for this store\n    at mshrs.scala:346 assert(is_hit, \"We still don't have permissions for this store\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174723:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_1377))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174726: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174726, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174734:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174745:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174748: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174748, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174756:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174767:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_3__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174770: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_3\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174770, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2625(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2625\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174624:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_615))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:131 assert(!(state === s_invalid && !rpq.io.empty))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174635:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_615))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174638: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174638, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174646:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174657:11
done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174660: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174660, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174668:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174679:11
done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174682: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174682, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174690:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_1022))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:240 assert(!(!grant_had_data && req_needs_wb))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174701:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_1022))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174704: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174704, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174712:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_1377))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: We still don't have permissions for this store\n    at mshrs.scala:346 assert(is_hit, \"We still don't have permissions for this store\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174723:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_1377))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174726: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174726, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174734:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174745:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174748: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174748, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174756:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174767:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_2__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174770: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_2\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174770, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2626(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2626\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174624:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_615))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:131 assert(!(state === s_invalid && !rpq.io.empty))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174635:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_615))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174638: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174638, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174646:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174657:11
done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174660: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174660, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174668:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174679:11
done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174682: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174682, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174690:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_1022))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:240 assert(!(!grant_had_data && req_needs_wb))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174701:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_1022))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174704: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174704, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174712:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_1377))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: We still don't have permissions for this store\n    at mshrs.scala:346 assert(is_hit, \"We still don't have permissions for this store\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174723:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_1377))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174726: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174726, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174734:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174745:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174748: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174748, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174756:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174767:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_1__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174770: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_1\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174770, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2627(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2627\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174624:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_615))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:131 assert(!(state === s_invalid && !rpq.io.empty))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174635:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_615))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174638: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174638, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174646:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174657:11
done_reset        
    ) {
        if (VL_UNLIKELY((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state)) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174660: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174660, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174668:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174679:11
done_reset        
    ) {
        if (VL_UNLIKELY((((((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state)) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174682: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174682, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174690:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_1022))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:240 assert(!(!grant_had_data && req_needs_wb))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174701:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_4231) 
                           & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__refill_done)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_1022))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174704: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174704, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174712:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_1377))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: We still don't have permissions for this store\n    at mshrs.scala:346 assert(is_hit, \"We still don't have permissions for this store\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174723:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_4259) 
                           & (0xcU == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_1262)) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_1377))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174726: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174726, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174734:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:183 assert(rpq.io.enq.ready)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174745:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_4259) 
                                 & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                                & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                               & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                              & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                             & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                            & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_1392))) 
                           & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_618))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_617)) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__rpq__DOT__full)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174748: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174748, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174756:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at mshrs.scala:190 assert(isWrite(io.req.uop.mem_cmd))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174767:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((((((((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___GEN_4259) 
                                   & (0xcU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                                  & (0xdU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                                 & (0xeU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                                & (0xfU != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                               & (0x11U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT__state))) 
                              & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_1392))) 
                             & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_618))) 
                            & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_617)) 
                           & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__s2_tag_match_way_0))) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_832)) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__dcache__DOT__mshrs__DOT__mshrs_0__DOT___T_382) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:174770: Assertion failed in %NTestHarness.top.boom_tile.dcache.mshrs.mshrs_0\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 174770, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2628(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2628\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:339928:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__ALUExeUnit__DOT__BranchKillableQueue_io_empty)
                           ? (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__ALUExeUnit__DOT__ifpu_io_resp_valid)
                           : (((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__ALUExeUnit__DOT__BranchKillableQueue_io_empty)) 
                               & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__ALUExeUnit__DOT__BranchKillableQueue__DOT___GEN_4)) 
                              & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__ALUExeUnit__DOT__BranchKillableQueue__DOT___T_8) 
                                    & (0U != ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__ALUExeUnit__DOT__alu__DOT__br_unit_brinfo_mask) 
                                              & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__ALUExeUnit__DOT__BranchKillableQueue__DOT__out_uop_br_mask))))))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT___T_259))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at fp-pipeline.scala:181 when (ifpu_resp.valid) { assert (ifpu_resp.bits.uop.rf_wen && ifpu_resp.bits.uop.dst_rtype === RT_FLT) }\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:339939:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__ALUExeUnit__DOT__BranchKillableQueue_io_empty)
                           ? (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__ALUExeUnit__DOT__ifpu_io_resp_valid)
                           : (((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__ALUExeUnit__DOT__BranchKillableQueue_io_empty)) 
                               & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__ALUExeUnit__DOT__BranchKillableQueue__DOT___GEN_4)) 
                              & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__ALUExeUnit__DOT__BranchKillableQueue__DOT___T_8) 
                                    & (0U != ((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__ALUExeUnit__DOT__alu__DOT__br_unit_brinfo_mask) 
                                              & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__ALUExeUnit__DOT__BranchKillableQueue__DOT__out_uop_br_mask))))))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT___T_259))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:339942: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 339942, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:339972:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit_io_fresp_valid) 
                         & (~ ((2U != (3U & ((vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT___T_221[4U] 
                                              << 0x13U) 
                                             | (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT___T_221[3U] 
                                                >> 0xdU)))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: rf_wen must be high here\n    at fp-pipeline.scala:198 assert(eu.io.fresp.bits.uop.rf_wen, \"rf_wen must be high here\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:339983:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit_io_fresp_valid) 
                         & (~ ((2U != (3U & ((vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT___T_221[4U] 
                                              << 0x13U) 
                                             | (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT___T_221[3U] 
                                                >> 0xdU)))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:339986: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 339986, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:339994:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit_io_fresp_valid) 
                         & (~ ((1U == (3U & ((vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT___T_221[4U] 
                                              << 0x13U) 
                                             | (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT___T_221[3U] 
                                                >> 0xdU)))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: wb type must be FLT for fpu\n    at fp-pipeline.scala:199 assert(eu.io.fresp.bits.uop.dst_rtype === RT_FLT, \"wb type must be FLT for fpu\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:340005:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit_io_fresp_valid) 
                         & (~ ((1U == (3U & ((vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT___T_221[4U] 
                                              << 0x13U) 
                                             | (vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fpiu_unit__DOT___T_221[3U] 
                                                >> 0xdU)))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:340008: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 340008, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:340016:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT___T_285))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at fp-pipeline.scala:239 assert(!(exe_resp.valid && wb_uop.uses_ldq))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:340027:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT___T_285))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:340030: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 340030, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:340038:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT___T_290))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at fp-pipeline.scala:240 assert(!(exe_resp.valid && wb_uop.uses_stq))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:340049:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT___T_290))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:340052: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 340052, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:340060:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT___T_295))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at fp-pipeline.scala:241 assert(!(exe_resp.valid && wb_uop.is_amo))\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:340071:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT___T_295))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:340074: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 340074, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2629(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2629\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_15 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_15;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_13 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_13;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_10 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_10;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_11 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_11;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_12 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_12;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_9 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_9;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_21 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_21;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_16 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_16;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_26 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_26;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_14 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_14;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_25 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_25;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_22 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_22;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_23 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_23;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_24 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_24;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_17 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_17;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_18 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_18;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_19 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_19;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_20 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_20;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_27 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_27;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_28 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_28;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_29 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_29;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_30 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_30;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_2 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_2;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_31 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_31;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_3 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_3;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_1 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_1;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_4 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_4;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_5 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_5;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_6 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_6;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_7 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__br_snapshots_0_7;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2630(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2630\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_8 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__rename_stage__DOT__maptable__DOT__map_table_8;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_15 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_15;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_13 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_13;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_10 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_10;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_11 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_11;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_8 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_8;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_9 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_9;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_14 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_14;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_12 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_12;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_24 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_24;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_21 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_21;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_22 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_22;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_19 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_19;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_23 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_23;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_16 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_16;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_17 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_17;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_18 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_18;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_0 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_0;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_20 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_20;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_5 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_5;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_7 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_7;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_25 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_25;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_26 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_26;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_27 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_27;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_28 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_28;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_29 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_29;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_1 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_1;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_30 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_30;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_2 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_2;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_31 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_31;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_3 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__br_snapshots_0_3;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_4 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_4;
    vlTOPp->__Vdly__TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_6 
        = vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_rename_stage__DOT__maptable__DOT__map_table_6;
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2634(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2634\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_31\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_31\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_31\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_31\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_31\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_31__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_31\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2635(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2635\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_31\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_31\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_31\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_31\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_31\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_31__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_31\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2636(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2636\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_31_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_31__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_31_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_31__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_31\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_30\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_30\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_30\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_30\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_30\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_30__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_30\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2637(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2637\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_29\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_29\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_29\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_29\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_29\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_29__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_29\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2638(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2638\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_30\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_30\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_30\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_30\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_30\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_30__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_30\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2639(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2639\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_30_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_30__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_30_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_30__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_30\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_29\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_29\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_29\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_29\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_29\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_29__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_29\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2640(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2640\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_28\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_28\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_28\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_28\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_28\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_28__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_28\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2641(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2641\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_29_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_29__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_29_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_29__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_29\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_28\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_28\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_28\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_28\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_28\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_28__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_28\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2642(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2642\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_27__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2643(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2643\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295814:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_28_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_28__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295825:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_28_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_28__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:295828: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_28\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 295828, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2644(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2644\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385541:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385552:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385555: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385555, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385563:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_60))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385574:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_60))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385577: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385577, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385585:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385596:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_65) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385599: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385599, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385607:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385618:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_73) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385621: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385621, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385629:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385640:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385643: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385643, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385651:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385662:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.threeWideMegaBoomConfig.top.v:385665: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.threeWideMegaBoomConfig/chipyard.TestHarness.threeWideMegaBoomConfig.top.v", 385665, "");
        }
    }
}
