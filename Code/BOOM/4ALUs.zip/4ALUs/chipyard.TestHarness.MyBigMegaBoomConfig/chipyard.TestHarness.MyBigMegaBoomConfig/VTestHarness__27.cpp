// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VTestHarness.h for the primary calling header

#include "VTestHarness.h"
#include "VTestHarness__Syms.h"

#include "verilated_dpi.h"

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2793(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2793\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_27__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2794(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2794\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302259:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_27_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_27__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302270:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_27_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_27__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302273: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_27\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 302273, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_26__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2795(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2795\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_26__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2796(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2796\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302259:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_26_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_26__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302270:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_26_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_26__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302273: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_26\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 302273, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_25\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_25\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_25\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_25\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_25\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_25__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_25\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2797(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2797\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_25\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_25\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_25\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_25\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_25\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_25__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_25\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2798(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2798\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302259:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_25_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_25__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302270:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_25_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_25__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302273: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_25\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 302273, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_24\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_24\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_24\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_24\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_24\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_24__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_24\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2799(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2799\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_24\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_24\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_24\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_24\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_24\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_24__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_24\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2800(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2800\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302259:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_24_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_24__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302270:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_24_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_24__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302273: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_24\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 302273, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_23\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_23\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_23\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_23\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_23\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_23__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_23\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2801(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2801\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_23\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_23\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_23\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_23\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_23\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_23__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_23\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2802(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2802\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302259:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_23_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_23__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302270:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_23_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_23__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302273: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_23\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 302273, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_22\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_22\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_22\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_22\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_22\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_22__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_22\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2803(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2803\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_22\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_22\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_22\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_22\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_22\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_22__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_22\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2804(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2804\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302259:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_22_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_22__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302270:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_22_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_22__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302273: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_22\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 302273, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_21\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_21\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_21\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_21\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_21\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_21__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_21\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2805(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2805\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_21\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_21\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_21\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_21\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_21\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_21__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_21\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2806(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2806\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302259:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_21_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_21__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302270:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_21_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_21__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302273: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_21\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 302273, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_20\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_20\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_20\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_20\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_20\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_20__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_20\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2807(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2807\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_20\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_20\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_20\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_20\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_20\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_20__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_20\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2808(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2808\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302259:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_20_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_20__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302270:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_20_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_20__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302273: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_20\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 302273, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_19\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_19\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_19\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_19\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_19\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_19__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_19\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2809(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2809\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_19\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_19\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_19\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_19\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_19\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_19__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_19\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2814(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2814\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__bim__DOT__Queue__DOT___T_cfi_idx__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__bim__DOT__Queue__DOT___T_mispredicted__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__bim__DOT__Queue__DOT___T_taken__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__bim__DOT__Queue_2__DOT___T_cfi_idx__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__bim__DOT__Queue_2__DOT___T_mispredicted__v0 = 0U;
    vlTOPp->__Vdlyvset__TestHarness__DOT__top__DOT__boom_tile__DOT__frontend__DOT__bpdpipeline__DOT__btb__DOT__bim__DOT__Queue_2__DOT___T_taken__v0 = 0U;
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302259:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_19_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_19__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302270:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_19_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_19__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302273: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_19\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 302273, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2815(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2815\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_18\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_18\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_18\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_18\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_18\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_18__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_18\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2816(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2816\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_18\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_18\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_18\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_18\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_18\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_18__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_18\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2817(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2817\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302259:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_18_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_18__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302270:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_18_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_18__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302273: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_18\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 302273, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_17\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_17\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_17\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_17\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_17\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_17__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_17\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2818(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2818\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_17\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_17\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_17\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_17\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_17\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_17__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_17\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2819(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2819\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302259:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_17_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_17__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302270:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_17_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_17__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302273: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_17\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 302273, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_16\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_16\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_16\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_16\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_16\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_16__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_16\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2820(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2820\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_16\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_16\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_16\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_16\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_16\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_16__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_16\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2821(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2821\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302259:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_16_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_16__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302270:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_16_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_16__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302273: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_16\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 302273, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_15\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_15\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_15\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_15\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_15\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_15__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_15\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2822(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2822\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_15\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_15\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_15\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_15\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_15\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_15__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_15\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2823(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2823\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302259:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_15_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_15__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302270:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_15_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_15__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302273: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_15\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 302273, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_14\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_14\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_14\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_14\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_14\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_14__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_14\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2824(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2824\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_14\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_14\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_14\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_14\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_14\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_14__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_14\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2825(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2825\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302259:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_14_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_14__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302270:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_14_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__fp_pipeline__DOT__fp_issue_unit__DOT__slots_14__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:302273: Assertion failed in %NTestHarness.top.boom_tile.core.fp_pipeline.fp_issue_unit.slots_14\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 302273, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_13\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_13\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_13\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_13\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_13\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__mem_issue_unit__DOT__slots_13__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.mem_issue_unit.slots_13\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2826(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2826\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488725:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT___T_21))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: trying to overwrite a valid issue slot.\n    at issue-slot.scala:153 assert (is_invalid || io.clear || io.kill, \"trying to overwrite a valid issue slot.\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488736:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13_io_in_uop_valid) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT___T_21))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488739: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_13\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488739, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488747:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT___T_90))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Loads to x0 should never speculatively wakeup other instructions\n    at issue-slot.scala:185 assert (!(io.ldspec_dst.valid && io.ldspec_dst.bits === 0.U),\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488758:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT___T_90))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488761: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_13\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488761, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488769:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:192 assert (!next_p1_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488780:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT___T_95) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT__next_p1_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488783: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_13\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488783, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488791:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed\n    at issue-slot.scala:197 assert (!next_p2_poisoned)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488802:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT___T_103) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT__next_p2_poisoned)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488805: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_13\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488805, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488813:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs1=x0!\n    at issue-slot.scala:201 assert(next_uop.prs1 =/= 0.U, \"Poison bit can't be set for prs1=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488824:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT__next_p1_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT__next_uop_prs1)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488827: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_13\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488827, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488835:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: Poison bit can't be set for prs2=x0!\n    at issue-slot.scala:205 assert(next_uop.prs2 =/= 0.U, \"Poison bit can't be set for prs2=x0!\")\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488846:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__lsu_io_core_ld_miss) 
                          & (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT__next_p2_poisoned)) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__boom_tile__DOT__core__DOT__int_issue_unit__DOT__slots_13__DOT__next_uop_prs2)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:488849: Assertion failed in %NTestHarness.top.boom_tile.core.int_issue_unit.slots_13\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 488849, "");
        }
    }
}
