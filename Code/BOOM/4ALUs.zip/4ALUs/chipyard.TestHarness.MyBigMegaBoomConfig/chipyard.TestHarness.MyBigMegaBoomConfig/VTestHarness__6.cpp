// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VTestHarness.h for the primary calling header

#include "VTestHarness.h"
#include "VTestHarness__Syms.h"

#include "verilated_dpi.h"

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2612(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2612\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117711:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries AcquireBlock type unsupported by manager (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:51 assert (edge.manager.supportsAcquireBSafe(edge.address(bundle), bundle.size), \"'A' channel carries AcquireBlock type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117722:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117725: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 117725, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117733:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_225))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries AcquireBlock from a client which does not support Probe (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:52 assert (edge.client.supportsProbe(edge.source(bundle), bundle.size), \"'A' channel carries AcquireBlock from a client which does not support Probe\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117744:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_225))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117747: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 117747, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117755:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock carries invalid source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:53 assert (source_ok, \"'A' channel AcquireBlock carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117766:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117769: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 117769, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117777:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_size)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock smaller than a beat (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:54 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'A' channel AcquireBlock smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117788:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_size)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117791: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 117791, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117799:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock address not aligned to size (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:55 assert (is_aligned, \"'A' channel AcquireBlock address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117810:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117813: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 117813, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117821:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((2U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock carries invalid grow param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:56 assert (TLPermissions.isGrow(bundle.param), \"'A' channel AcquireBlock carries invalid grow param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117832:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((2U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117835: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 117835, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117843:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((0U == (0xffU & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget_auto_out_a_bits_mask)))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock contains invalid mask (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:57 assert (~bundle.mask === 0.U, \"'A' channel AcquireBlock contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117854:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((0U == (0xffU & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget_auto_out_a_bits_mask)))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117857: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 117857, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117865:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock is corrupt (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:58 assert (!bundle.corrupt, \"'A' channel AcquireBlock is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117876:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117879: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 117879, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117887:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries AcquirePerm type unsupported by manager (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:62 assert (edge.manager.supportsAcquireBSafe(edge.address(bundle), bundle.size), \"'A' channel carries AcquirePerm type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117898:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117901: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 117901, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117909:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_225))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries AcquirePerm from a client which does not support Probe (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:63 assert (edge.client.supportsProbe(edge.source(bundle), bundle.size), \"'A' channel carries AcquirePerm from a client which does not support Probe\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117920:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_225))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117923: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 117923, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117931:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm carries invalid source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:64 assert (source_ok, \"'A' channel AcquirePerm carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117942:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117945: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 117945, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117953:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_size)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm smaller than a beat (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:65 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'A' channel AcquirePerm smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117964:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_size)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117967: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 117967, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117975:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm address not aligned to size (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:66 assert (is_aligned, \"'A' channel AcquirePerm address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117986:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117989: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 117989, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:117997:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((2U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm carries invalid grow param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:67 assert (TLPermissions.isGrow(bundle.param), \"'A' channel AcquirePerm carries invalid grow param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118008:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((2U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118011: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118011, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118019:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm requests NtoB (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:68 assert (bundle.param =/= TLPermissions.NtoB, \"'A' channel AcquirePerm requests NtoB\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118030:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118033: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118033, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118041:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((0U == (0xffU & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget_auto_out_a_bits_mask)))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm contains invalid mask (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:69 assert (~bundle.mask === 0.U, \"'A' channel AcquirePerm contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118052:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((0U == (0xffU & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget_auto_out_a_bits_mask)))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118055: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118055, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118063:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm is corrupt (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:70 assert (!bundle.corrupt, \"'A' channel AcquirePerm is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118074:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (7U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118077: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118077, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118085:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_410))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries Get type unsupported by manager (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:74 assert (edge.manager.supportsGetSafe(edge.address(bundle), bundle.size), \"'A' channel carries Get type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118096:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_410))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118099: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118099, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118107:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get carries invalid source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:75 assert (source_ok, \"'A' channel Get carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118118:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118121: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118121, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118129:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get address not aligned to size (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:76 assert (is_aligned, \"'A' channel Get address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118140:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118143: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118143, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118151:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get carries invalid param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:77 assert (bundle.param === 0.U, \"'A' channel Get carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118162:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118165: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118165, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118173:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_424))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get contains invalid mask (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:78 assert (bundle.mask === mask, \"'A' channel Get contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118184:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_424))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118187: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118187, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118195:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get is corrupt (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:79 assert (!bundle.corrupt, \"'A' channel Get is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118206:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118209: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118209, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118217:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_486))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries PutFull type unsupported by manager (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:83 assert (edge.manager.supportsPutFullSafe(edge.address(bundle), bundle.size), \"'A' channel carries PutFull type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118228:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_486))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118231: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118231, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118239:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutFull carries invalid source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:84 assert (source_ok, \"'A' channel PutFull carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118250:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118253: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118253, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118261:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutFull address not aligned to size (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:85 assert (is_aligned, \"'A' channel PutFull address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118272:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118275: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118275, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118283:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutFull carries invalid param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:86 assert (bundle.param === 0.U, \"'A' channel PutFull carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118294:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118297: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118297, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118305:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_424))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutFull contains invalid mask (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:87 assert (bundle.mask === mask, \"'A' channel PutFull contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118316:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_424))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118319: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118319, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118327:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_486))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries PutPartial type unsupported by manager (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:91 assert (edge.manager.supportsPutPartialSafe(edge.address(bundle), bundle.size), \"'A' channel carries PutPartial type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118338:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_486))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118341: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118341, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118349:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutPartial carries invalid source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:92 assert (source_ok, \"'A' channel PutPartial carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118360:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118363: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118363, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118371:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutPartial address not aligned to size (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:93 assert (is_aligned, \"'A' channel PutPartial address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118382:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118385: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118385, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118393:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutPartial carries invalid param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:94 assert (bundle.param === 0.U, \"'A' channel PutPartial carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118404:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118407: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118407, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118415:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_574))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutPartial contains invalid mask (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:95 assert ((bundle.mask & ~mask) === 0.U, \"'A' channel PutPartial contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118426:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_574))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118429: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118429, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118437:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_627))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries Arithmetic type unsupported by manager (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:99 assert (edge.manager.supportsArithmeticSafe(edge.address(bundle), bundle.size), \"'A' channel carries Arithmetic type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118448:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_627))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118451: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118451, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118459:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Arithmetic carries invalid source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:100 assert (source_ok, \"'A' channel Arithmetic carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118470:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118473: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118473, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118481:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Arithmetic address not aligned to size (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:101 assert (is_aligned, \"'A' channel Arithmetic address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118492:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118495: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118495, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118503:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((4U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Arithmetic carries invalid opcode param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:102 assert (TLAtomics.isArithmetic(bundle.param), \"'A' channel Arithmetic carries invalid opcode param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118514:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((4U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118517: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118517, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118525:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_424))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Arithmetic contains invalid mask (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:103 assert (bundle.mask === mask, \"'A' channel Arithmetic contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118536:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_424))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118539: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118539, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118547:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_627))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries Logical type unsupported by manager (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:107 assert (edge.manager.supportsLogicalSafe(edge.address(bundle), bundle.size), \"'A' channel carries Logical type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118558:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_627))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118561: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118561, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118569:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Logical carries invalid source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:108 assert (source_ok, \"'A' channel Logical carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118580:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118583: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118583, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118591:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Logical address not aligned to size (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:109 assert (is_aligned, \"'A' channel Logical address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118602:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118605: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118605, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118613:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((3U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Logical carries invalid opcode param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:110 assert (TLAtomics.isLogical(bundle.param), \"'A' channel Logical carries invalid opcode param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118624:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((3U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_param)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118627: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118627, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118635:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_424))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Logical contains invalid mask (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:111 assert (bundle.mask === mask, \"'A' channel Logical contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118646:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (3U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_424))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118649: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118649, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118657:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_366) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries Hint type unsupported by manager (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:115 assert (edge.manager.supportsHintSafe(edge.address(bundle), bundle.size), \"'A' channel carries Hint type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118668:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_366) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118671: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118671, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118679:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Hint carries invalid source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:116 assert (source_ok, \"'A' channel Hint carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118690:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_228))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118693: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118693, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118701:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Hint address not aligned to size (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:117 assert (is_aligned, \"'A' channel Hint address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118712:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_235))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118715: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118715, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118723:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_424))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Hint contains invalid mask (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:118 assert (bundle.mask === mask, \"'A' channel Hint contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118734:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_424))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118737: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118737, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118745:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Hint is corrupt (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:119 assert (!bundle.corrupt, \"'A' channel Hint is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118756:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118759: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118759, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118767:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                         & (~ ((6U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel has invalid opcode (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:270 assert (TLMessages.isD(bundle.opcode), \"'D' channel has invalid opcode\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118778:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                         & (~ ((6U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118781: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118781, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118789:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_806))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel ReleaseAck carries invalid source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:278 assert (source_ok, \"'D' channel ReleaseAck carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118800:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_806))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118803: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118803, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118811:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_size___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel ReleaseAck smaller than a beat (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:279 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'D' channel ReleaseAck smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118822:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_size___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118825: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118825, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118833:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel ReleaseeAck carries invalid param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:280 assert (bundle.param === 0.U, \"'D' channel ReleaseeAck carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118844:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118847: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118847, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118855:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel ReleaseAck is corrupt (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:281 assert (!bundle.corrupt, \"'D' channel ReleaseAck is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118866:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118869: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118869, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118877:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_denied)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel ReleaseAck is denied (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:282 assert (!bundle.denied, \"'D' channel ReleaseAck is denied\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118888:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (6U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_denied)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118891: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118891, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118899:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_806))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant carries invalid source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:286 assert (source_ok, \"'D' channel Grant carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118910:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_806))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118913: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118913, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118921:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant carries invalid sink ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:287 assert (sink_ok, \"'D' channel Grant carries invalid sink ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118932:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118935: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118935, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118943:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_size___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant smaller than a beat (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:288 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'D' channel Grant smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118954:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_size___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118957: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118957, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118965:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((2U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant carries invalid cap param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:289 assert (TLPermissions.isCap(bundle.param), \"'D' channel Grant carries invalid cap param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118976:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((2U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118979: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 118979, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118987:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((2U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant carries toN param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:290 assert (bundle.param =/= TLPermissions.toN, \"'D' channel Grant carries toN param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:118998:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((2U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119001: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119001, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119009:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant is corrupt (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:291 assert (!bundle.corrupt, \"'D' channel Grant is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119020:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (4U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119023: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119023, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119031:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_806))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData carries invalid source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:296 assert (source_ok, \"'D' channel GrantData carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119042:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_806))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119045: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119045, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119053:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData carries invalid sink ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:297 assert (sink_ok, \"'D' channel GrantData carries invalid sink ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119064:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119067: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119067, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119075:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_size___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData smaller than a beat (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:298 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'D' channel GrantData smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119086:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_size___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119089: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119089, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119097:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((2U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData carries invalid cap param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:299 assert (TLPermissions.isCap(bundle.param), \"'D' channel GrantData carries invalid cap param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119108:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((2U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119111: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119111, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119119:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((2U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData carries toN param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:300 assert (bundle.param =/= TLPermissions.toN, \"'D' channel GrantData carries toN param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119130:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((2U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119133: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119133, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119141:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_874))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData is denied but not corrupt (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:301 assert (!bundle.denied || bundle.corrupt, \"'D' channel GrantData is denied but not corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119152:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (5U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_874))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119155: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119155, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119163:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_806))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAck carries invalid source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:306 assert (source_ok, \"'D' channel AccessAck carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119174:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_806))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119177: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119177, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119185:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAck carries invalid param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:308 assert (bundle.param === 0.U, \"'D' channel AccessAck carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119196:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119199: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119199, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119207:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAck is corrupt (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:309 assert (!bundle.corrupt, \"'D' channel AccessAck is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119218:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119221: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119221, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119229:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_806))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAckData carries invalid source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:314 assert (source_ok, \"'D' channel AccessAckData carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119240:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_806))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119243: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119243, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119251:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAckData carries invalid param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:316 assert (bundle.param === 0.U, \"'D' channel AccessAckData carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119262:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119265: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119265, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119273:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_874))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAckData is denied but not corrupt (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:317 assert (!bundle.denied || bundle.corrupt, \"'D' channel AccessAckData is denied but not corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119284:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (1U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_874))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119287: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119287, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119295:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_806))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel HintAck carries invalid source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:322 assert (source_ok, \"'D' channel HintAck carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119306:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_806))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119309: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119309, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119317:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel HintAck carries invalid param (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:324 assert (bundle.param === 0.U, \"'D' channel HintAck carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119328:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer__DOT__Queue_1__DOT___T_param___05FT_18_data)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119331: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119331, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119339:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel HintAck is corrupt (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:325 assert (!bundle.corrupt, \"'D' channel HintAck is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119350:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (2U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_corrupt)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119353: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119353, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119361:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_957))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_977))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel opcode changed within multibeat operation (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:357 assert (a.bits.opcode === opcode, \"'A' channel opcode changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119372:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_957))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_977))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119375: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119375, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119383:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_957))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_981))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel param changed within multibeat operation (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:358 assert (a.bits.param  === param,  \"'A' channel param changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119394:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_957))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_981))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119397: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119397, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119405:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_957))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_985))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel size changed within multibeat operation (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:359 assert (a.bits.size   === size,   \"'A' channel size changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119416:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_957))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_985))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119419: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119419, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119427:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_957))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_989))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel source changed within multibeat operation (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:360 assert (a.bits.source === source, \"'A' channel source changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119438:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_957))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_989))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119441: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119441, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119449:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_957))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_993))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel address changed with multibeat operation (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:361 assert (a.bits.address=== address,\"'A' channel address changed with multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119460:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__sbus__DOT__coupler_to_bus_named_periphery_bus__DOT__widget__DOT__Repeater_io_deq_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_957))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_993))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119463: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119463, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119471:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1005))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1026))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel opcode changed within multibeat operation (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:427 assert (d.bits.opcode === opcode, \"'D' channel opcode changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119482:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1005))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1026))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119485: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119485, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119493:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1005))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1030))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel param changed within multibeat operation (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:428 assert (d.bits.param  === param,  \"'D' channel param changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119504:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1005))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1030))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119507: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119507, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119515:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1005))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1034))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel size changed within multibeat operation (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:429 assert (d.bits.size   === size,   \"'D' channel size changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119526:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1005))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1034))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119529: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119529, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119537:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1005))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1038))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel source changed within multibeat operation (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:430 assert (d.bits.source === source, \"'D' channel source changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119548:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1005))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1038))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119551: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119551, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119559:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1005))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1042))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel sink changed with multibeat operation (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:431 assert (d.bits.sink   === sink,   \"'D' channel sink changed with multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119570:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1005))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1042))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119573: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119573, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119581:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1005))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1046))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel denied changed with multibeat operation (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:432 assert (d.bits.denied === denied, \"'D' channel denied changed with multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119592:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1005))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1046))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119595: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119595, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119603:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_948) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1060))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1099))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel re-used a source ID (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:462 assert(!inflight(bundle.a.bits.source), \"'A' channel re-used a source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119614:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_948) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1060))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1099))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119617: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119617, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119625:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_997) 
                           & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1079))) 
                          & (6U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1113))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel acknowledged for nothing inflight (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:469 assert((a_set | inflight)(bundle.d.bits.source), \"'D' channel acknowledged for nothing inflight\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119636:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_997) 
                           & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1079))) 
                          & (6U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__atomics_auto_in_d_bits_opcode))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1113))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119639: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119639, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119647:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1120))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' and 'D' concurrent, despite minlatency 2 (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:473 assert(a_set =/= d_clr || !a_set.orR, s\"'A' and 'D' concurrent, despite minlatency ${edge.manager.minLatency}\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119658:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1120))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119661: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119661, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119669:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1133))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: TileLink timeout expired (connected at CrossingHelper.scala:17:44)\n    at Monitor.scala:481 assert (!inflight.orR || limit === 0.U || watchdog < limit, \"TileLink timeout expired\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119680:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__cbus__DOT__buffer_1__DOT__TLMonitor__DOT___T_1133))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:119683: Assertion failed in %NTestHarness.top.cbus.buffer_1.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 119683, "");
        }
    }
}

VL_INLINE_OPT void VTestHarness::_sequent__TOP__2613(VTestHarness__Syms* __restrict vlSymsp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VTestHarness::_sequent__TOP__2613\n"); );
    VTestHarness* __restrict vlTOPp VL_ATTR_UNUSED = vlSymsp->TOPp;
    // Body
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:68937:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries AcquireBlock type unsupported by manager (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:51 assert (edge.manager.supportsAcquireBSafe(edge.address(bundle), bundle.size), \"'A' channel carries AcquireBlock type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:68948:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:68951: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 68951, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:68959:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries AcquireBlock from a client which does not support Probe (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:52 assert (edge.client.supportsProbe(edge.source(bundle), bundle.size), \"'A' channel carries AcquireBlock from a client which does not support Probe\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:68970:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:68973: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 68973, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:68981:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock carries invalid source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:53 assert (source_ok, \"'A' channel AcquireBlock carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:68992:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:68995: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 68995, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69003:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((3U <= (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0xeU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock smaller than a beat (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:54 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'A' channel AcquireBlock smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69014:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((3U <= (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0xeU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69017: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69017, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69025:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock address not aligned to size (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:55 assert (is_aligned, \"'A' channel AcquireBlock address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69036:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69039: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69039, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69047:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((2U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock carries invalid grow param (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:56 assert (TLPermissions.isGrow(bundle.param), \"'A' channel AcquireBlock carries invalid grow param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69058:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((2U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69061: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69061, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69069:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0U == (0xffU & (~ (
                                                   (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                    << 0x1fU) 
                                                   | (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[2U] 
                                                      >> 1U))))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock contains invalid mask (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:57 assert (~bundle.mask === 0.U, \"'A' channel AcquireBlock contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69080:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0U == (0xffU & (~ (
                                                   (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                    << 0x1fU) 
                                                   | (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[2U] 
                                                      >> 1U))))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69083: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69083, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69091:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquireBlock is corrupt (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:58 assert (!bundle.corrupt, \"'A' channel AcquireBlock is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69102:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (6U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69105: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69105, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69113:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries AcquirePerm type unsupported by manager (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:62 assert (edge.manager.supportsAcquireBSafe(edge.address(bundle), bundle.size), \"'A' channel carries AcquirePerm type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69124:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69127: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69127, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69135:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries AcquirePerm from a client which does not support Probe (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:63 assert (edge.client.supportsProbe(edge.source(bundle), bundle.size), \"'A' channel carries AcquirePerm from a client which does not support Probe\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69146:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69149: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69149, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69157:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm carries invalid source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:64 assert (source_ok, \"'A' channel AcquirePerm carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69168:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69171: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69171, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69179:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((3U <= (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0xeU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm smaller than a beat (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:65 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'A' channel AcquirePerm smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69190:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((3U <= (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0xeU))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69193: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69193, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69201:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm address not aligned to size (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:66 assert (is_aligned, \"'A' channel AcquirePerm address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69212:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69215: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69215, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69223:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((2U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm carries invalid grow param (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:67 assert (TLPermissions.isGrow(bundle.param), \"'A' channel AcquirePerm carries invalid grow param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69234:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((2U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69237: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69237, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69245:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0U != (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm requests NtoB (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:68 assert (bundle.param =/= TLPermissions.NtoB, \"'A' channel AcquirePerm requests NtoB\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69256:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0U != (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69259: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69259, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69267:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0U == (0xffU & (~ (
                                                   (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                    << 0x1fU) 
                                                   | (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[2U] 
                                                      >> 1U))))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm contains invalid mask (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:69 assert (~bundle.mask === 0.U, \"'A' channel AcquirePerm contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69278:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0U == (0xffU & (~ (
                                                   (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                    << 0x1fU) 
                                                   | (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[2U] 
                                                      >> 1U))))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69281: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69281, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69289:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel AcquirePerm is corrupt (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:70 assert (!bundle.corrupt, \"'A' channel AcquirePerm is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69300:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (7U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69303: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69303, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69311:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_194))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries Get type unsupported by manager (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:74 assert (edge.manager.supportsGetSafe(edge.address(bundle), bundle.size), \"'A' channel carries Get type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69322:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_194))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69325: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69325, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69333:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get carries invalid source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:75 assert (source_ok, \"'A' channel Get carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69344:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69347: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69347, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69355:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get address not aligned to size (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:76 assert (is_aligned, \"'A' channel Get address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69366:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69369: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69369, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69377:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get carries invalid param (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:77 assert (bundle.param === 0.U, \"'A' channel Get carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69388:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69391: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69391, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69399:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_208))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get contains invalid mask (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:78 assert (bundle.mask === mask, \"'A' channel Get contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69410:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_208))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69413: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69413, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69421:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Get is corrupt (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:79 assert (!bundle.corrupt, \"'A' channel Get is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69432:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (4U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69435: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69435, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69443:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_194))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries PutFull type unsupported by manager (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:83 assert (edge.manager.supportsPutFullSafe(edge.address(bundle), bundle.size), \"'A' channel carries PutFull type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69454:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_194))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69457: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69457, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69465:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutFull carries invalid source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:84 assert (source_ok, \"'A' channel PutFull carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69476:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69479: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69479, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69487:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutFull address not aligned to size (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:85 assert (is_aligned, \"'A' channel PutFull address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69498:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69501: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69501, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69509:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutFull carries invalid param (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:86 assert (bundle.param === 0.U, \"'A' channel PutFull carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69520:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69523: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69523, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69531:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_208))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutFull contains invalid mask (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:87 assert (bundle.mask === mask, \"'A' channel PutFull contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69542:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_208))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69545: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69545, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69553:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_194))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries PutPartial type unsupported by manager (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:91 assert (edge.manager.supportsPutPartialSafe(edge.address(bundle), bundle.size), \"'A' channel carries PutPartial type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69564:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_194))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69567: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69567, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69575:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutPartial carries invalid source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:92 assert (source_ok, \"'A' channel PutPartial carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69586:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69589: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69589, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69597:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutPartial address not aligned to size (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:93 assert (is_aligned, \"'A' channel PutPartial address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69608:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69611: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69611, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69619:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutPartial carries invalid param (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:94 assert (bundle.param === 0.U, \"'A' channel PutPartial carries invalid param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69630:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69633: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69633, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69641:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_272))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel PutPartial contains invalid mask (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:95 assert ((bundle.mask & ~mask) === 0.U, \"'A' channel PutPartial contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69652:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (1U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_272))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69655: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69655, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69663:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries Arithmetic type unsupported by manager (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:99 assert (edge.manager.supportsArithmeticSafe(edge.address(bundle), bundle.size), \"'A' channel carries Arithmetic type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69674:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69677: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69677, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69685:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Arithmetic carries invalid source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:100 assert (source_ok, \"'A' channel Arithmetic carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69696:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69699: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69699, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69707:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Arithmetic address not aligned to size (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:101 assert (is_aligned, \"'A' channel Arithmetic address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69718:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69721: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69721, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69729:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((4U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Arithmetic carries invalid opcode param (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:102 assert (TLAtomics.isArithmetic(bundle.param), \"'A' channel Arithmetic carries invalid opcode param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69740:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((4U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69743: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69743, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69751:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_208))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Arithmetic contains invalid mask (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:103 assert (bundle.mask === mask, \"'A' channel Arithmetic contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69762:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (2U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_208))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69765: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69765, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69773:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries Logical type unsupported by manager (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:107 assert (edge.manager.supportsLogicalSafe(edge.address(bundle), bundle.size), \"'A' channel carries Logical type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69784:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69787: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69787, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69795:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Logical carries invalid source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:108 assert (source_ok, \"'A' channel Logical carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69806:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69809: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69809, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69817:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Logical address not aligned to size (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:109 assert (is_aligned, \"'A' channel Logical address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69828:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69831: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69831, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69839:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((3U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Logical carries invalid opcode param (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:110 assert (TLAtomics.isLogical(bundle.param), \"'A' channel Logical carries invalid opcode param\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69850:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((3U >= (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                             >> 0x11U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69853: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69853, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69861:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_208))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Logical contains invalid mask (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:111 assert (bundle.mask === mask, \"'A' channel Logical contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69872:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (3U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_208))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69875: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69875, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69883:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel carries Hint type unsupported by manager (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:115 assert (edge.manager.supportsHintSafe(edge.address(bundle), bundle.size), \"'A' channel carries Hint type unsupported by manager\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69894:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69897: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69897, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69905:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Hint carries invalid source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:116 assert (source_ok, \"'A' channel Hint carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69916:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((0x13U >= (0x1fU & (
                                                   vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                                   >> 9U))) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69919: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69919, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69927:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Hint address not aligned to size (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:117 assert (is_aligned, \"'A' channel Hint address not aligned to size\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69938:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_124))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69941: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69941, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69949:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_208))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Hint contains invalid mask (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:118 assert (bundle.mask === mask, \"'A' channel Hint contains invalid mask\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69960:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_208))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69963: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69963, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69971:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel Hint is corrupt (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:119 assert (!bundle.corrupt, \"'A' channel Hint is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69982:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (5U == (7U & (vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[3U] 
                                          >> 0x14U)))) 
                         & (~ ((~ vlTOPp->TestHarness__DOT__top__DOT__cork__DOT___T_274[0U]) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69985: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 69985, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:69993:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                         & (~ ((6U >= ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                        ? 1U : 0U)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel has invalid opcode (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:270 assert (TLMessages.isD(bundle.opcode), \"'D' channel has invalid opcode\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70004:11
done_reset        
    ) {
        if (VL_UNLIKELY(((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                         & (~ ((6U >= ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                        ? 1U : 0U)) 
                               | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70007: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70007, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70015:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (6U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((0x13U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_source)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel ReleaseAck carries invalid source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:278 assert (source_ok, \"'D' channel ReleaseAck carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70026:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (6U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((0x13U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_source)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70029: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70029, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70037:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (6U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_size)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel ReleaseAck smaller than a beat (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:279 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'D' channel ReleaseAck smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70048:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (6U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_size)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70051: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70051, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70059:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (6U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_corrupt)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel ReleaseAck is corrupt (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:281 assert (!bundle.corrupt, \"'D' channel ReleaseAck is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70070:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (6U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_corrupt)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70073: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70073, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70081:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (6U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_denied)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel ReleaseAck is denied (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:282 assert (!bundle.denied, \"'D' channel ReleaseAck is denied\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70092:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (6U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_denied)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70095: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70095, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70103:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (4U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((0x13U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_source)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant carries invalid source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:286 assert (source_ok, \"'D' channel Grant carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70114:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (4U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((0x13U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_source)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70117: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70117, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70125:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (4U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant carries invalid sink ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:287 assert (sink_ok, \"'D' channel Grant carries invalid sink ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70136:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (4U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70139: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70139, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70147:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (4U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_size)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant smaller than a beat (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:288 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'D' channel Grant smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70158:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (4U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_size)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70161: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70161, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70169:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (4U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_corrupt)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel Grant is corrupt (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:291 assert (!bundle.corrupt, \"'D' channel Grant is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70180:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (4U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_corrupt)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70183: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70183, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70191:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (5U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((0x13U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_source)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData carries invalid source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:296 assert (source_ok, \"'D' channel GrantData carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70202:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (5U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((0x13U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_source)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70205: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70205, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70213:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (5U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ (IData)(vlTOPp->reset))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData carries invalid sink ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:297 assert (sink_ok, \"'D' channel GrantData carries invalid sink ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70224:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (5U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ (IData)(vlTOPp->reset))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70227: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70227, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70235:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (5U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_size)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData smaller than a beat (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:298 assert (bundle.size >= log2Ceil(edge.manager.beatBytes).U, \"'D' channel GrantData smaller than a beat\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70246:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (5U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((3U <= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_size)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70249: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70249, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70257:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (5U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_436))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel GrantData is denied but not corrupt (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:301 assert (!bundle.denied || bundle.corrupt, \"'D' channel GrantData is denied but not corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70268:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (5U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_436))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70271: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70271, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70279:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (0U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((0x13U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_source)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAck carries invalid source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:306 assert (source_ok, \"'D' channel AccessAck carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70290:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (0U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((0x13U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_source)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70293: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70293, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70301:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (0U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_corrupt)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAck is corrupt (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:309 assert (!bundle.corrupt, \"'D' channel AccessAck is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70312:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (0U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_corrupt)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70315: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70315, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70323:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (1U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((0x13U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_source)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAckData carries invalid source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:314 assert (source_ok, \"'D' channel AccessAckData carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70334:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (1U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((0x13U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_source)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70337: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70337, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70345:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (1U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_436))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel AccessAckData is denied but not corrupt (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:317 assert (!bundle.denied || bundle.corrupt, \"'D' channel AccessAckData is denied but not corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70356:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (1U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_436))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70359: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70359, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70367:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (2U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((0x13U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_source)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel HintAck carries invalid source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:322 assert (source_ok, \"'D' channel HintAck carries invalid source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70378:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (2U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((0x13U >= (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_source)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70381: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70381, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70389:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (2U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_corrupt)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel HintAck is corrupt (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:325 assert (!bundle.corrupt, \"'D' channel HintAck is corrupt\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70400:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (2U == ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ ((~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_bits_corrupt)) 
                             | (IData)(vlTOPp->reset)))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70403: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70403, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70411:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_519))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_539))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel opcode changed within multibeat operation (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:357 assert (a.bits.opcode === opcode, \"'A' channel opcode changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70422:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_519))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_539))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70425: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70425, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70433:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_519))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_543))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel param changed within multibeat operation (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:358 assert (a.bits.param  === param,  \"'A' channel param changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70444:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_519))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_543))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70447: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70447, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70455:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_519))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_547))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel size changed within multibeat operation (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:359 assert (a.bits.size   === size,   \"'A' channel size changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70466:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_519))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_547))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70469: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70469, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70477:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_519))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_551))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel source changed within multibeat operation (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:360 assert (a.bits.source === source, \"'A' channel source changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70488:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_519))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_551))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70491: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70491, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70499:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_519))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_555))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel address changed with multibeat operation (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:361 assert (a.bits.address=== address,\"'A' channel address changed with multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70510:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__cork_auto_out_a_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_519))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_555))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70513: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70513, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70521:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_567))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_588))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel opcode changed within multibeat operation (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:427 assert (d.bits.opcode === opcode, \"'D' channel opcode changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70532:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_567))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_588))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70535: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70535, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70543:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_567))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_596))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel size changed within multibeat operation (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:429 assert (d.bits.size   === size,   \"'D' channel size changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70554:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_567))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_596))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70557: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70557, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70565:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_567))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_600))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel source changed within multibeat operation (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:430 assert (d.bits.source === source, \"'D' channel source changed within multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70576:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_567))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_600))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70579: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70579, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70587:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_567))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_608))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel denied changed with multibeat operation (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:432 assert (d.bits.denied === denied, \"'D' channel denied changed with multibeat operation\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70598:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor_io_in_d_valid) 
                          & (0U != (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_567))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_608))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70601: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70601, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70609:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_510) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_622))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_661))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' channel re-used a source ID (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:462 assert(!inflight(bundle.a.bits.source), \"'A' channel re-used a source ID\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70620:11
done_reset        
    ) {
        if (VL_UNLIKELY((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_510) 
                          & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_622))) 
                         & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_661))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70623: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70623, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70631:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_559) 
                           & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_641))) 
                          & (6U != ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_675))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'D' channel acknowledged for nothing inflight (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:469 assert((a_set | inflight)(bundle.d.bits.source), \"'D' channel acknowledged for nothing inflight\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70642:11
done_reset        
    ) {
        if (VL_UNLIKELY(((((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_559) 
                           & (0U == (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_641))) 
                          & (6U != ((IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT___T_81)
                                     ? 1U : 0U))) & 
                         (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_675))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70645: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70645, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70653:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_682))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: 'A' and 'D' concurrent, despite minlatency 1 (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:473 assert(a_set =/= d_clr || !a_set.orR, s\"'A' and 'D' concurrent, despite minlatency ${edge.manager.minLatency}\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70664:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_682))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70667: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70667, "");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70675:11
verbose&&done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_695))))) {
            VL_FWRITEF(0x80000002U,"Assertion failed: TileLink timeout expired (connected at MemoryBus.scala:67:46)\n    at Monitor.scala:481 assert (!inflight.orR || limit === 0.U || watchdog < limit, \"TileLink timeout expired\" + extra)\n");
        }
    }
    if (
        // $c function at /home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70686:11
done_reset        
    ) {
        if (VL_UNLIKELY((1U & (~ (IData)(vlTOPp->TestHarness__DOT__top__DOT__mbus__DOT__coupler_to_memory_controller_named_axi4__DOT__tl2axi4__DOT__TLMonitor__DOT___T_695))))) {
            VL_WRITEF("[%0t] %%Error: chipyard.TestHarness.MyBigMegaBoomConfig.top.v:70689: Assertion failed in %NTestHarness.top.mbus.coupler_to_memory_controller_named_axi4.tl2axi4.TLMonitor\n",
                      64,VL_TIME_Q(),vlSymsp->name());
            VL_STOP_MT("/home/azimgivron/chipyard/sims/verilator/generated-src/chipyard.TestHarness.MyBigMegaBoomConfig/chipyard.TestHarness.MyBigMegaBoomConfig.top.v", 70689, "");
        }
    }
}
