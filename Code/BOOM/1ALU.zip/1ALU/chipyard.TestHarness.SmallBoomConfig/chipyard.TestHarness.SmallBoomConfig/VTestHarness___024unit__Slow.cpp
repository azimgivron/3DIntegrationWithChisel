// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VTestHarness.h for the primary calling header

#include "VTestHarness___024unit.h"
#include "VTestHarness__Syms.h"

#include "verilated_dpi.h"

//==========

VL_CTOR_IMP(VTestHarness___024unit) {
    // Reset internal values
    // Reset structure values
    _ctor_var_reset();
}

void VTestHarness___024unit::__Vconfigure(VTestHarness__Syms* vlSymsp, bool first) {
    if (0 && first) {}  // Prevent unused
    this->__VlSymsp = vlSymsp;
}

VTestHarness___024unit::~VTestHarness___024unit() {
}

void VTestHarness___024unit::_ctor_var_reset() {
    VL_DEBUG_IF(VL_DBG_MSGF("+        VTestHarness___024unit::_ctor_var_reset\n"); );
}
